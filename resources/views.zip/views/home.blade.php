<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from cartzilla.createx.studio/home-nft.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Aug 2022 18:10:41 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title>{{$settings->website_name}} | Home</title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="{{$settings->home_meta_d}}">
    <meta name="keywords" content="{{$settings->home_meta_k}}">
    <meta name="author" content="Createx Studio">
    <!-- Viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('storage/' . ($settings->icon))}}">
    <link rel="mask-icon" color="#fe6a6a" href="{{ asset('safari-pinned-tab.svg') }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="{{ asset('vendor/simplebar/dist/simplebar.min.css') }}"/>
    <link rel="stylesheet" media="screen" href="{{ asset('vendor/tiny-slider/dist/tiny-slider.css') }}"/>
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="{{ asset('css/theme.min.css') }}">
    <style>
      .card {
        height: 100%; /* Ensures the card fills the container height */
      }

      .card-body {
        display: flex;
        flex-direction: column;
        justify-content: space-between; /* Distributes space between the card title and description */
      }

      .card-footer {
        flex-shrink: 0; /* Prevents the footer from shrinking */
      }
      .card-img-top {
    width: 100%; /* Full width of the card */
    height: 200px; /* Fixed height for the image container */
    overflow: hidden; /* Hide any overflowed content */
    display: flex;
    align-items: center; /* Center the image vertically */
    justify-content: center; /* Center the image horizontally */
    position: relative; /* Ensure proper positioning of overlay elements */
  }

  .card-img-top img {
    width: 100%;
    height: 200px; /* Ensure the image fills the container */
    object-fit: cover; /* Cover the container, maintaining aspect ratio */
  }

  .small-alert {
        font-size: 0.875rem; /* Smaller font size */
        padding: 0.5rem 1rem; /* Smaller padding */
    }

    /* Optional: Fade-out animation */
    .fade-out {
        transition: opacity 0.5s ease-in-out;
        opacity: 0;
    }
    .btn-close {
        position: absolute;
        top: 3rem; /* المسافة من الأعلى */
        left: 2rem; /* المسافة من اليسار */
        z-index: 1050; /* التأكد من بقاء الزر فوق المحتوى */
    }
    @media (max-width: 768px) {
      .bg-size-cover{
        margin-top: 100px
      }
    }
    </style>

    <!-- Google Tag Manager-->

  </head>
  <!-- Body-->
  <body class="handheld-toolbar-enabled" style="background-color: white;">
    <!-- Google Tag Manager (noscript)-->

    <!-- Sign in / sign up modal-->
    @include('Includes.signin_signup')

    <main class="page-wrapper">
      <!-- Navbar for NFT Marketplace demo-->
      <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->

      @include('Includes.home_header')

      @if (session('success'))
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '{{ session('success') }}',
                showConfirmButton: false,
                timer: 3000 // 3 seconds
            });
        });
    </script>
@endif

<!-- Check if there are any errors -->
@if ($errors->any())
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let errorMessage = '';
            @foreach ($errors->all() as $error)
                errorMessage += '{{ $error }}\n';
            @endforeach

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                showConfirmButton: false,
                timer: 3000 // 3 seconds
            });
        });
    </script>
@endif
      <!-- Hero-->
      <section class="mb-lg-2 bg-faded-accent bg-size-cover" style="padding-top: 80px; background-image: url(img/nft/home/hero-bg.png);direction: rtl; text-align: right;">
        <div class="container py-4">
          <div class="row align-items-center justify-content-center gy-3 py-3 text-lg-start text-center">
            <div class="col-lg-5 col-md-8 col-sm-10">
              <h1 class="mb-4 pb-lg-2" style="direction: rtl; text-align: right;">نقدم حلول تسويق إلكتروني شاملة لتحقيق أهداف عملك الرقمية.</h1>
              <p class="mb-lg-5 mb-4 fs-lg" style="direction: rtl; text-align: right;">نساعدك على زيادة ظهورك الرقمي والوصول إلى جمهورك المستهدف من خلال استراتيجيات تسويقية فعّالة.</p>
              <div class="d-lg-flex d-none flex-sm-row flex-column justify-content-lg-start justify-content-center">
                <a class="btn btn-lg btn-accent me-sm-3 mb-sm-3 mb-2 m-2" href="{{route('services')}}" style="direction: rtl; text-align: right;">تصفح خدماتنا</a>
                @if (!Auth::user())
                <a class="btn btn-lg btn-outline-dark mb-sm-3 mb-2 m-2" href="#signup-modal" data-bs-toggle="modal" style="direction: rtl; text-align: right;">انشئ حساب</a>
                @endif
            </div>
            </div>
            <div class="modal fade" id="signup-modal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header bg-secondary">
                            <ul class="nav nav-tabs card-header-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link fw-medium" href="#signup-tab" role="tab" aria-selected="true">
                                        <i class="ci-user me-2 mt-n1"></i>Sign up
                                    </a>
                                </li>
                            </ul>
                            <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body py-4">
                            <form class="needs-validation" autocomplete="off" novalidate action="{{ route('Registeration') }}" method="POST">
                                @csrf
                                <div class="mb-3">
                                    <label class="form-label" for="su-name">Full name</label>
                                    <input class="form-control" type="text" id="userName" name="userName" placeholder="John Doe" required>
                                    <div class="invalid-feedback">Please fill in your name.</div>
                                </div>
                                <div class="mb-3">
                                    <label for="su-email">Email address</label>
                                    <input class="form-control" type="email" id="email" name="email" placeholder="johndoe@example.com" required>
                                    <div class="invalid-feedback">Please provide a valid email address.</div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="su-password">Password</label>
                                    <div class="password-toggle">
                                        <input class="form-control" type="password" id="password" name="password" required>
                                        <label class="password-toggle-btn" aria-label="Show/hide password">
                                            <input class="password-toggle-check" type="checkbox">
                                            <span class="password-toggle-indicator"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="su-password-confirm">Phone Number</label>
                                    <input class="form-control" type="text" id="phone" name="phone" required>
                                </div>
                                <button class="btn btn-primary btn-shadow d-block w-100" type="submit">Sign up</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-8 offset-lg-1 col-sm-10">
              <!-- Top auctions carousel-->
              <div class="tns-carousel tns-nav-enabled mb-4 mx-n2">
                <div class="tns-carousel-inner" data-carousel-options="{&quot;controls&quot;: false}">
                  <!-- Carousel item-->
                  @foreach ($HomeAds as $item)
                  <div class="px-2"><img class="rounded-3" src="{{ asset('storage/' . ($item->image ?? 'default_icon.jpg')) }}" alt="Product">
                    <div class="position-relative">
                      <div class="position-absolute start-0 bottom-0 w-100 p-md-5 p-sm-4 p-3">
                        <div class="pt-sm-0 pt-2 px-sm-4 px-2 bg-white rounded shadow">
                          <div class="row gx-5">
                            <div class="col-sm-4 col-6 position-relative py-sm-3 py-2">
                              <h6 class="mb-1 fs-sm fw-normal text-muted">Description:</h6><span class="h6 mb-0">{{$item->description}}</span>
                            </div>
                            <div class="col-sm-4 col-6 position-relative py-sm-3 py-2">
                              {{-- <hr class="hr-vertical position-absolute start-0 top-0 ml-n4"> --}}
                              <h6 class="mb-1 fs-sm fw-normal text-muted">Ends in:</h6><span class="h6 mb-0">{{$item->end_date}}</span>
                            </div>
                            {{-- <div class="col-sm-4 position-relative py-sm-3 py-2"> --}}
                              
                              {{-- <div class="d-flex align-items-center h-100"><a class="btn btn-sm btn-dark w-100" href="{{$item->button_url}}">Start bid</a></div> --}}
                            {{-- </div> --}}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  @endforeach


                </div>
              </div>
              <div class="d-lg-none d-flex flex-sm-row flex-column justify-content-lg-start justify-content-center"><a class="btn btn-lg btn-accent me-sm-3 mb-2" href="{{ route('services') }}">Explore marketplace</a>
            </div>
          </div>
        </div>
      </section>
            <!-- Product carousel (Trending in)-->
      <!-- Product carousel (Recent Drops)-->
      <section class="container mb-2 py-lg-5 py-4">
        <div class="d-flex align-items-center justify-content-between mb-sm-3 mb-2"  style="direction: rtl; text-align: right;">
          <h2 class="h3 mb-0"  style="direction: rtl; text-align: right;">ابرز الأقسام</h2><a class="btn btn-outline-accent ms-3" href="{{ route('services') }}">اكتشف المزيد<i class="ci-arrow-right ms-2"></i></a>
        </div>
        <!-- Product carousel-->
        <div class="tns-carousel tns-controls-static tns-controls-outside mx-xl-n4 mx-n2 px-xl-4 px-0">
          <div class="tns-carousel-inner row gx-xl-0 gx-3 mx-0" data-carousel-options="{&quot;items&quot;: 2, &quot;nav&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1,&quot;controls&quot;: false, &quot;gutter&quot;: 0},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}, &quot;1100&quot;:{&quot;items&quot;:4}, &quot;1278&quot;:{&quot;controls&quot;: true, &quot;nav&quot;: false, &quot;gutter&quot;: 30}}}">

            @foreach ($categories as $category)
              <div class="col py-3">
                <article class="card h-100 border-0 shadow">
                  <div class="card-img-top position-relative overflow-hidden">
                    <a href="{{ route('categories', $category->category_id) }}" class="d-block">
                      <img src="{{ asset('storage/' . $category->category_img) }}" alt="Category Image">
                    </a>
                    <!-- Wishlist button-->
                    </button>
                  </div>
                  <div class="card-body">
                    <h3 class="product-title mb-2 fs-base">
                      <a class="d-block text-truncate" href="{{ route('categories', $category->category_id) }}">{{ $category->category_name }}</a>
                    </h3>
                    <span class="fs-sm text-muted">Description:</span>
                    <p class="fs-sm text-muted">{{ $category->category_description }}</p>
                  </div>
                  <div class="card-footer mt-n1 py-0 border-0">
                  </div>
                </article>
              </div>
            @endforeach

          </div>
        </div>

      </section>

      <section class="mb-4 py-5 bg-secondary">
        <div class="container py-lg-4">
            <div class="d-flex flex-wrap mb-3" style="direction: rtl; text-align: right;">
                <h2 class="h3 mb-0" style="direction: rtl; text-align: right;">ابرز الخدمات</h2>

            </div>

            <!-- Product carousel -->
            <div class="tns-carousel tns-controls-static tns-controls-outside mx-xl-n4 mx-n2 px-xl-4 px-0">
              <div class="tns-carousel-inner row gx-xl-0 gx-3 mx-0" data-carousel-options="{&quot;items&quot;: 2, &quot;nav&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1,&quot;controls&quot;: false, &quot;gutter&quot;: 0},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}, &quot;1100&quot;:{&quot;items&quot;:4}, &quot;1278&quot;:{&quot;controls&quot;: true, &quot;gutter&quot;: 30}}}">
                  @foreach($products as $product)
                  <div class="col py-3">
                      {{-- <a href="#signinnn-modal" data-bs-toggle="modal"
                         data-product-name="{{ $product->product_name }}"
                         data-product-img="{{ $product->Product_img ? asset('storage/' . $product->Product_img) : asset('img/default-product-image.jpg') }}"
                         data-product-salary="{{ $product->product_salary }}"
                         data-description="{{ $product->description }}"
                         data-duration="{{ $product->Duration_of_righteousness }}"
                         data-bs-target="#signinnn-modal"> --}}
                          <article class="card h-100 border-0 shadow">
                              <div class="card-img-top position-relative overflow-hidden">
                                  <img class="avatar" src="{{ $product->Product_img ? asset('storage/' . $product->Product_img) : asset('img/default-product-image.jpg') }}" alt="Product image">
                                  <button
                                      class="btn-wishlist btn-sm position-absolute top-0 end-0"
                                      type="button"
                                      data-bs-toggle="tooltip"
                                      data-bs-placement="left"
                                      title="Add to Favorites"
                                      style="margin: 12px;"
                                      onclick="addToFavorites({{ $product->product_id }})">
                                      <i class="ci-heart"></i>
                                  </button>
                              </div>

                              <div class="card-body">
                                  <a href="#signinnn-modal" data-bs-toggle="modal"
                              data-product-name="{{ $product->product_name }}"
                              data-product-img="{{ $product->Product_img ? asset('storage/' . $product->Product_img) : asset('img/default-product-image.jpg') }}"
                              data-product-salary="{{ $product->product_salary }}"
                              data-description="{{ $product->description }}"
                              data-duration="{{ $product->Duration_of_righteousness }}"
                              data-bs-target="#signinnn-modal">
                                  <h3 class="product-title mb-2 fs-base">{{ $product->product_name }}</h3>
                                  <span class="fs-sm text-muted">السعر:</span>
                                  <div class="d-flex align-items-center flex-wrap">
                                      <h4 class="mt-1 mb-0 fs-base text-darker">{{ $product->product_salary }} SAR</h4>
                                  </div>
                              </div>
                          </article>
                      </a>
                  </div>
                   @endforeach
              </div>
          </div>
        </div>
    </section>

    <div class="modal fade" id="signinnn-modal" tabindex="-1" role="dialog"  style="direction: rtl; text-align: right;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header bg-secondary">
                    <h5 class="modal-title">Product Details</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pb-0">
                    <div class="d-sm-flex justify-content-between mb-4 pb-3 pb-sm-2 border-bottom">
                        <div class="d-sm-flex text-center text-sm-start">
                            <a class="d-inline-block flex-shrink-0 mx-auto" style="width: 15rem;">
                                <img id="modal-product-img" src="" alt="Product" style="width: 100%; height: auto;">
                            </a>
                            <div class="ps-sm-4 pt-2">
                                <h3 id="modal-product-name" class="product-title fs-base mb-2"></h3>
                                <div class="fs-sm"><span class="text-muted me-2">Description:</span><span id="modal-description"></span></div>
                                <div class="fs-sm"><span class="text-muted me-2">Duration:</span><span id="modal-duration"></span></div>
                                <div class="fs-lg text-accent pt-2">Price: <span id="modal-product-salary"></span></div>
                                <div class="mt-3">
                                  <a href="{{ route('contacts.index') }}" class="btn btn-outline-primary">طلب الخدمه عبر الايميل</a>
                                  <a href="https://api.whatsapp.com/send?phone={{$settings->whatsapp}}&text=مرحبا"  class="btn btn-outline-success">طلب الخدمه عبر الواتساب</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Styles -->
    <style>
        .card {
            transition: box-shadow 0.3s ease; /* Smooth transition for the shadow effect */
            width: 300px; /* Adjust the width as needed */
            height: 400px; /* Adjust the height as needed */
        }

        .card-img-top img {
            width: 100%; /* Make the image cover the card width */
            height: 200px; /* Adjust the height as needed */
            object-fit: cover; /* Ensure the image covers the area without distortion */
        }

        .modal-dialog {
            max-width: 800px; /* Adjust the width of the modal as needed */
        }

        .modal-content {
            padding: 1.5rem; /* Adjust the padding inside the modal as needed */
        }

        .modal-body {
            padding: 2rem; /* Adjust the padding inside the modal body as needed */
        }

        .card:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Change the values as needed */
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var productModal = document.getElementById('signinnn-modal');
            productModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget; // Button that triggered the modal

                // Get the product data from the button's data attributes
                var productName = button.getAttribute('data-product-name');
                var productImg = button.getAttribute('data-product-img');
                var productSalary = button.getAttribute('data-product-salary');
                var description = button.getAttribute('data-description');
                var duration = button.getAttribute('data-duration');

                // Find the modal elements
                var modalProductName = productModal.querySelector('#modal-product-name');
                var modalProductImg = productModal.querySelector('#modal-product-img');
                var modalProductSalary = productModal.querySelector('#modal-product-salary');
                var modalDescription = productModal.querySelector('#modal-description');
                var modalDuration = productModal.querySelector('#modal-duration');

                // Set the modal content
                modalProductName.textContent = productName;
                modalProductImg.src = productImg;
                modalProductSalary.textContent = productSalary;
                modalDescription.textContent = description;
                modalDuration.textContent = duration;
            });
        });
    </script>


    <!-- Features-->
    <section class="container py-lg-5 py-4">
    <h2 class="mb-4 pb-md-3 pb-2" style="direction: rtl; text-align: right;">ابدأ رحلتك في التسويق الإلكتروني معنا!</h2>
    <!-- Features carousel-->
    <div class="tns-carousel mb-4">
      <div class="tns-carousel-inner" data-carousel-options="{&quot;items&quot;: 2, &quot;nav&quot;: true, &quot;gutter&quot;: 30, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1,&quot;controls&quot;: false},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}, &quot;1100&quot;:{&quot;items&quot;:4}, &quot;1278&quot;:{&quot;controls&quot;: true}}}">
        <!-- Carousel item-->
        <div style="direction: rtl; text-align: right;"><img class="mb-4" src="img/nft/features/wallet.svg" width="60" alt="Icon">
          <h4 class="mb-2 fs-lg text-body">حدد استراتيجيتك التسويقية</h4>
          <p class="mb-0 fs-sm text-muted">ابدأ بوضع استراتيجية تسويقية فعّالة لتحقيق أهدافك والوصول إلى جمهورك المستهدف.</p>
        </div>
        <!-- Carousel item-->
        <div style="direction: rtl; text-align: right;"> <img class="mb-4" src="img/nft/features/add.svg" width="60" alt="Icon">
          <h4 class="mb-2 fs-lg text-body">أنشئ حملاتك الإعلانية</h4>
          <p class="mb-0 fs-sm text-muted">صمم حملات إعلانية جذابة على مختلف المنصات لتحقيق نتائج متميزة.</p>
        </div>
        <!-- Carousel item-->
        <div style="direction: rtl; text-align: right;"><img class="mb-4" src="img/nft/features/image.svg" width="60" alt="Icon">
          <h4 class="mb-2 fs-lg text-body">إدارة محتوى وسائل التواصل الاجتماعي</h4>
          <p class="mb-0 fs-sm text-muted">قم بإدارة حساباتك على وسائل التواصل الاجتماعي وزيادة التفاعل مع جمهورك.</p>
        </div>
        <!-- Carousel item-->
        <div style="direction: rtl; text-align: right;"><img class="mb-4" src="img/nft/features/shopping-cart.svg" width="60" alt="Icon">
          <h4 class="mb-2 fs-lg text-body">تتبع وتحليل النتائج</h4>
          <p class="mb-0 fs-sm text-muted">قم بتحليل أداء حملاتك وتحسينها باستمرار لتحقيق أفضل النتائج الممكنة.</p>
        </div>
      </div>
    </div>
  </section>

    </main>
    <!-- Bg shape-->
    <div class="pt-4 bg-secondary">


    </div>
    <!-- Footer-->
    @include('Includes.footer')

    <!-- Toolbar for handheld devices (NFT Marketplace)-->
    @include('Includes.toolbar')

    <!-- Back To Top Button--><a class="btn-scroll-top" href="#top" data-scroll><span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span><i class="btn-scroll-top-icon ci-arrow-up">   </i></a>
    <!-- Vendor scrits: js libraries and plugins-->
    <script src="{{ asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('vendor/simplebar/dist/simplebar.min.js') }}"></script>
    <script src="{{ asset('vendor/tiny-slider/dist/min/tiny-slider.js') }}"></script>
    <script src="{{ asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js') }}"></script>
    <!-- Main theme script-->
    <script src="{{ asset('js/theme.min.js') }}"></script>

    <script>
      function addToFavorites(productId) {
    console.log('Adding product to favorites with ID:', productId);

    $.ajax({
        url: '{{ route('favorites.store') }}',
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',
            product_id: productId
        },
        success: function(response) {
            console.log('Success:', response);
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: response.message,
                confirmButtonText: 'OK'
            });
        },
        error: function(xhr) {
            console.error('AJAX Error:', xhr);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error adding to favorites: ' + xhr.responseText,
                confirmButtonText: 'OK'
            });
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
        setTimeout(function () {
            let alert = document.querySelectorAll('.alert-dismissible');
            alert.forEach(function (el) {
                el.classList.add('fade-out');
            });
        }, 3000); // 3 seconds

        // Completely remove the alert after the fade-out animation
        setTimeout(function () {
            let alert = document.querySelectorAll('.alert-dismissible');
            alert.forEach(function (el) {
                el.style.display = 'none';
            });
        }, 3500); // Wait 0.5 seconds more for the fade-out to complete
    });


      </script>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


  </body>

<!-- Mirrored from cartzilla.createx.studio/home-nft.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Aug 2022 18:11:55 GMT -->
</html>
