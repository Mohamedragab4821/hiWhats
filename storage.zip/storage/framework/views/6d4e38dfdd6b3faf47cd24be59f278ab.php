<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'size' => 'xl',
    'width' => [
        'omg' => '7xl',
        'xxl' => '6xl',
        'xl' => '4xl',
        'big' => '3xl',
        'medium' => '2xl',
        'small' => 'lg',
        'tiny' => 'md'
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'size' => 'xl',
    'width' => [
        'omg' => '7xl',
        'xxl' => '6xl',
        'xl' => '4xl',
        'big' => '3xl',
        'medium' => '2xl',
        'small' => 'lg',
        'tiny' => 'md'
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $sizes = ['omg', 'xxl', 'xl', 'big', 'medium', 'small', 'tiny'];

    if(! in_array($size, $sizes)) {
        dd('refer to centered-content/docs for approved sizes. https://bladewindui.com/component/centered-content');
    }
?>
<div class="max-w-md max-w-lg max-w-2xl max-w-3xl max-w-4xl max-w-6xl max-w-7xl "></div>
<div <?php echo e($attributes->merge(['class' => "max-w-$width[$size] mx-auto"])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\centered-content.blade.php ENDPATH**/ ?>