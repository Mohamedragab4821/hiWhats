<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo e($settings->website_name); ?> | Products</title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="<?php echo e($settings->product_meta_d); ?>">
    <meta name="keywords" content="<?php echo e($settings->product_meta_k); ?>">
    <meta name="author" content="Createx Studio">
    <!-- Viewport-->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('storage/' . ($settings->icon))); ?>">

    <link rel="mask-icon" color="#fe6a6a" href="<?php echo e(asset('safari-pinned-tab.svg')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.css')); ?>">
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/tiny-slider/dist/tiny-slider.css')); ?>">
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/theme.min.css')); ?>">

    <!-- Google Tag Manager-->
   
</head>
<body class="handheld-toolbar-enabled">
    <!-- Google Tag Manager (noscript)-->
    <noscript>
      <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-WKV3GT5" height="0" width="0" style="display: none; visibility: hidden;"></iframe>
    </noscript>
    <!-- Sign in / sign up modal-->
    <?php echo $__env->make('Includes.signin_signup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="page-wrapper">
      <!-- Navbar Marketplace-->
      <?php echo $__env->make('Includes.account_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- Used for marketplace templates with filters on top-->
      <div class="bg-accent pt-4 pb-5" style="background-color: #f6f9fc !important">
        <div class="container pt-2 pb-3 pt-lg-3 pb-lg-4">
          <div class="d-lg-flex justify-content-between pb-3">
            <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                  <li class="breadcrumb-item"><a style="color:black" class="text-nowrap" href="<?php echo e(route('home')); ?>"><i class="ci-home"></i>الصفحه الرئيسيه</a></li>
                  </li>
                </ol>
              </nav>
            </div>
            <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
              <h1 class="h3 text-dark mb-0">خدمات <?php echo e($settings->website_name); ?></h1>
            </div>
          </div>
        </div>
      </div>
      <div class="container pb-5 mb-2 mb-md-4">
        <!-- Toolbar-->
        <div class="shadow-lg rounded-3 mt-n5 mb-4">
          <div class="d-flex align-items-center ps-2">
              <!-- Search-->
              <form action="<?php echo e(route('services.search')); ?>" method="GET" class="d-flex align-items-center">
                  <input type="text" name="search" placeholder="Search..." class="form-control me-2">
                  <button type="submit" class="btn btn-primary">Search</button>
              </form>
          </div>
        </div>
        <!-- Products grid-->
        <div class="row pt-3 mx-n2">
          <!-- Product-->
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-4 col-sm-6 px-2 mb-grid-gutter">
            <div class="card product-card-alt">
              <div class="product-thumb" style="height: 280px;width: 280px;" >
                <button
                    class="btn-wishlist btn-sm position-absolute top-0 end-0"
                    type="button"
                    data-bs-toggle="tooltip"
                    data-bs-placement="left"
                    title="Add to Favorites"
                    style="margin: 12px;"
                    onclick="addToFavorites(<?php echo e($product->product_id); ?>)"
                >
                    <i class="ci-heart"></i>
                </button>
                <div class="product-card-actions"><a class="btn btn-light btn-icon btn-shadow fs-base mx-2" href="#signinnn-modal" data-bs-toggle="modal"
                    data-product-name="<?php echo e($product->product_name); ?>"
                       data-product-img="<?php echo e($product->Product_img ? asset('storage/' . $product->Product_img) : asset('img/default-product-image.jpg')); ?>"
                       data-product-salary="<?php echo e($product->product_salary); ?>"
                       data-description="<?php echo e($product->description); ?>"
                       data-duration="<?php echo e($product->Duration_of_righteousness); ?>"
                       data-bs-target="#signinnn-modal"><i class="ci-eye"></i></a>
                </div><a class="product-thumb-overlay"></a><img src="<?php echo e(asset('storage/'.$product->Product_img)); ?>" alt="Product">
              </div>
              <div class="card-body">
                <h3 class="product-title fs-sm mb-2"><a href="marketplace-single.html"><?php echo e($product->product_name); ?></a></h3>
                <div class="d-flex flex-wrap justify-content-between align-items-center">
                  <div class="fs-sm me-2"><?php echo e($product->category_name); ?></div>
                  <div class="bg-faded-accent text-accent rounded-1 py-1 px-2"><?php echo e($product->product_name); ?></div>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="modal fade" id="signinnn-modal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-secondary">
                        <h5 class="modal-title">Product Details</h5>
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pb-0">
                      <div class="d-sm-flex justify-content-between mb-4 pb-3 pb-sm-2 border-bottom">
                          <div class="d-sm-flex text-center text-sm-start">
                              <a class="d-inline-block flex-shrink-0 mx-auto" style="width: 15rem;">
                                  <img id="modal-product-img" src="" alt="Product" style="width: 100%; height: auto;">
                              </a>
                              <div class="ps-sm-4 pt-2">
                                  <h3 id="modal-product-name" class="product-title fs-base mb-2"></h3>
                                  <div class="fs-sm"><span class="text-muted me-2">Description:</span><span id="modal-description"></span></div>
                                  <div class="fs-sm"><span class="text-muted me-2">Duration:</span><span id="modal-duration"></span></div>
                                  <div class="fs-lg text-accent pt-2">Price: <span id="modal-product-salary"></span></div>
                                  <div class="mt-3">
                                    <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-outline-primary">طلب الخدمه عبر الايميل</a>
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo e($settings->whatsapp); ?>&text=مرحبا"  class="btn btn-outline-success">طلب الخدمه عبر الواتساب</a>

                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var productModal = document.getElementById('signinnn-modal');
                productModal.addEventListener('show.bs.modal', function(event) {
                    var button = event.relatedTarget; // Button that triggered the modal

                    // Get the product data from the button's data attributes
                    var productName = button.getAttribute('data-product-name');
                    var productImg = button.getAttribute('data-product-img');
                    var productSalary = button.getAttribute('data-product-salary');
                    var description = button.getAttribute('data-description');
                    var duration = button.getAttribute('data-duration');

                    // Find the modal elements
                    var modalProductName = productModal.querySelector('#modal-product-name');
                    var modalProductImg = productModal.querySelector('#modal-product-img');
                    var modalProductSalary = productModal.querySelector('#modal-product-salary');
                    var modalDescription = productModal.querySelector('#modal-description');
                    var modalDuration = productModal.querySelector('#modal-duration');

                    // Set the modal content
                    modalProductName.textContent = productName;
                    modalProductImg.src = productImg;
                    modalProductSalary.textContent = productSalary;
                    modalDescription.textContent = description;
                    modalDuration.textContent = duration;
                });
            });
        </script>
        <hr class="my-3">
        <!-- Pagination-->
        <nav class="d-flex justify-content-between pt-2 mb-4" aria-label="Page navigation">
            <ul class="pagination">
                <li class="page-item <?php echo e($products->onFirstPage() ? 'disabled' : ''); ?>">
                    <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>"><i class="ci-arrow-left me-2"></i>السابق</a>
                </li>
            </ul>
            <ul class="pagination">
                <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                    <li class="page-item <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
            <ul class="pagination">
                <li class="page-item <?php echo e($products->hasMorePages() ? '' : 'disabled'); ?>">
                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">التالي<i class="ci-arrow-right ms-2"></i></a>
                </li>
            </ul>
        </nav>
      </div>
    </main>
    <!-- Footer-->
    <?php echo $__env->make('Includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Toolbar for handheld devices (Marketplace)-->
    <?php echo $__env->make('includes.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Back To Top Button--><a class="btn-scroll-top" href="#top" data-scroll><span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span><i class="btn-scroll-top-icon ci-arrow-up">   </i></a>
    <!-- Vendor scrits: js libraries and plugins-->
    <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')); ?>"></script>
    <!-- Main Theme Script-->
    <script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>
    <!-- Custom JS for pagination and other features-->
    <script>
      function addToFavorites(productId) {
          // Implement your favorite logic here
          alert('Product ' + productId + ' added to favorites!');
      }
    </script>
</body>
</html>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\resources\views/AllServices.blade.php ENDPATH**/ ?>