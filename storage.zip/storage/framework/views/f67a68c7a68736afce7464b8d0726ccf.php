<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    // where do you want the notification displayed
    // available options are top right, top center, top left, bottom right, bottom center, bottom left
    'position' => config('bladewind.notification.position', 'top-right'),
    'position_css' => [
        'top_right' => 'right-4 top-10',
        'top_center' => 'top-10', // FIXME::
        'top_left' => 'left-4 top-10',
        'bottom_right' => 'right-4 bottom-10',
        'bottom_center' => 'bottom-10', // FIXME::
        'bottom_left' => 'left-4 bottom-10',
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    // where do you want the notification displayed
    // available options are top right, top center, top left, bottom right, bottom center, bottom left
    'position' => config('bladewind.notification.position', 'top-right'),
    'position_css' => [
        'top_right' => 'right-4 top-10',
        'top_center' => 'top-10', // FIXME::
        'top_left' => 'left-4 top-10',
        'bottom_right' => 'right-4 bottom-10',
        'bottom_center' => 'bottom-10', // FIXME::
        'bottom_left' => 'left-4 bottom-10',
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // [type] is replaced with the type of notification in notification.js
    $css = "!size-14 p-2 rounded-full bg-[type]-200/80 dark:bg-[type]-600 text-[type]-600 dark:text-[type]-100";
    $position = str_replace(' ', '_', $position);
?>
<div class="fixed flex flex-col-reverse <?php echo e($position_css[str_replace('-', '_', $position)]); ?> z-50 bw-notification-container w-11/12 sm:!max-w-[450px]"></div>

<div class="bw-notification-icons hidden">
    <?php if (isset($component)) { $__componentOriginaldd9042d600e0aeb384f3deebb44f611b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal-icon','data' => ['class' => 'hidden '.e($css).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden '.e($css).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $attributes = $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $component = $__componentOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldd9042d600e0aeb384f3deebb44f611b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal-icon','data' => ['class' => 'hidden '.e($css).'','type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden '.e($css).'','type' => 'error']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $attributes = $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $component = $__componentOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldd9042d600e0aeb384f3deebb44f611b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal-icon','data' => ['class' => 'hidden '.e($css).'','type' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden '.e($css).'','type' => 'warning']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $attributes = $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $component = $__componentOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginaldd9042d600e0aeb384f3deebb44f611b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal-icon','data' => ['class' => 'hidden '.e($css).'','type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::modal-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden '.e($css).'','type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $attributes = $__attributesOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__attributesOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b)): ?>
<?php $component = $__componentOriginaldd9042d600e0aeb384f3deebb44f611b; ?>
<?php unset($__componentOriginaldd9042d600e0aeb384f3deebb44f611b); ?>
<?php endif; ?>
</div>

<script>
    <?php include_once('vendor/bladewind/js/notification.js'); ?>
</script><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\notification.blade.php ENDPATH**/ ?>