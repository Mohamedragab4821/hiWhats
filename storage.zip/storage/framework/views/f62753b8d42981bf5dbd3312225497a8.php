<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([ 
    'name' => 'process-complete',
    // available options are passed and failed
    // default is passed and it shows a green thumbsup icon
    // failed process shows a red thumbs down icon
    'process_completed_as' => 'passed',
    'processCompletedAs' => 'passed',

    // message to display when process is complete
    'message' => '',

    // text to display on the button when process is complete
    'button_label' => '',
    'buttonLabel' => '',
    
    // a javascript function that will be called when the button is clicked on
    'button_action' => '',
    'buttonAction' => '',
    'hide' => true,
    'class' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([ 
    'name' => 'process-complete',
    // available options are passed and failed
    // default is passed and it shows a green thumbsup icon
    // failed process shows a red thumbs down icon
    'process_completed_as' => 'passed',
    'processCompletedAs' => 'passed',

    // message to display when process is complete
    'message' => '',

    // text to display on the button when process is complete
    'button_label' => '',
    'buttonLabel' => '',
    
    // a javascript function that will be called when the button is clicked on
    'button_action' => '',
    'buttonAction' => '',
    'hide' => true,
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    if ($processCompletedAs !== $process_completed_as) $process_completed_as = $processCompletedAs;
    if ($buttonLabel !== $button_label) $button_label = $buttonLabel;
    if ($buttonAction !== $button_action) $button_action = $buttonAction;
    $hide = filter_var($hide, FILTER_VALIDATE_BOOLEAN);
    //------------------------------------------------------
    $name = preg_replace('/[\s]/', '-', $name);
?>
<div class="<?php echo e($name); ?> text-center mt-6 <?php if($hide): ?> hidden <?php endif; ?> <?php echo e($class); ?>">
    <?php if($process_completed_as === 'passed'): ?>
        <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'hand-thumb-up','type' => 'solid','class' => 'h-14 w-14 block mx-auto bg-green-500 text-white rounded-full p-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hand-thumb-up','type' => 'solid','class' => 'h-14 w-14 block mx-auto bg-green-500 text-white rounded-full p-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'hand-thumb-down','type' => 'solid','class' => 'h-14 w-14 block mx-auto bg-red-500 text-white rounded-full p-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hand-thumb-down','type' => 'solid','class' => 'h-14 w-14 block mx-auto bg-red-500 text-white rounded-full p-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
    <?php endif; ?>
    <div class="my-3 text-sm <?php if($process_completed_as === 'passed'): ?> text-green-600 dark:text-green-700 <?php else: ?> text-red-600 dark:text-red-400 <?php endif; ?>">
        <span class="process-message"><?php echo e($message); ?></span>
        <div class="mt-8"></div>
        <?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['type' => 'secondary','size' => 'tiny','onclick' => ''.e($button_action).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'secondary','size' => 'tiny','onclick' => ''.e($button_action).'']); ?><?php echo e($button_label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\process-complete.blade.php ENDPATH**/ ?>