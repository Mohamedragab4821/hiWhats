<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icons_array' => null, 'row' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icons_array' => null, 'row' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php if( !empty($icons_array) ): ?>
    <td class="text-right space-x-2 actions">
        <?php $__currentLoopData = $icons_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($icon['icon'])): ?>
                <?php if(!empty($icon['tip'])): ?>
                    <a data-tooltip="<?php echo e($icon['tip']); ?>" data-inverted="" data-position="top center"> <?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb4077406ec1be740458fd4823e4ae997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb4077406ec1be740458fd4823e4ae997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.circle','data' => ['size' => 'tiny','icon' => ''.e($icon['icon']).'','color' => ''.e($icon['color'] ?? '').'','onclick' => ''.build_click($icon['click'], $row) ?? 'void(0)'.'','type' => ''.isset($icon['color']) ? 'primary' : 'secondary'.'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'tiny','icon' => ''.e($icon['icon']).'','color' => ''.e($icon['color'] ?? '').'','onclick' => ''.build_click($icon['click'], $row) ?? 'void(0)'.'','type' => ''.isset($icon['color']) ? 'primary' : 'secondary'.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb4077406ec1be740458fd4823e4ae997)): ?>
<?php $attributes = $__attributesOriginalb4077406ec1be740458fd4823e4ae997; ?>
<?php unset($__attributesOriginalb4077406ec1be740458fd4823e4ae997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4077406ec1be740458fd4823e4ae997)): ?>
<?php $component = $__componentOriginalb4077406ec1be740458fd4823e4ae997; ?>
<?php unset($__componentOriginalb4077406ec1be740458fd4823e4ae997); ?>
<?php endif; ?>
                        <?php if(!empty($icon['tip'])): ?> </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
<?php endif; ?><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\table-icons.blade.php ENDPATH**/ ?>