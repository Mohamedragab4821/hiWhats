<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'lightIcon' => 'sun',
    'lightText' => 'Light',
    'darkIcon' => 'moon',
    'darkText' => 'Dark',
    'systemIcon' => 'computer-desktop',
    'systemText' => 'System',
    'iconRight' => true,
    'iconType' => 'outline',
    'iconDir' => '',
    'modular' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'lightIcon' => 'sun',
    'lightText' => 'Light',
    'darkIcon' => 'moon',
    'darkText' => 'Dark',
    'systemIcon' => 'computer-desktop',
    'systemText' => 'System',
    'iconRight' => true,
    'iconType' => 'outline',
    'iconDir' => '',
    'modular' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $iconRight = filter_var($iconRight, FILTER_VALIDATE_BOOLEAN);
    $modular = filter_var($modular, FILTER_VALIDATE_BOOLEAN);
?>
<?php if (! $__env->hasRenderedOnce('4bb80752-d69f-4d87-8854-b5bb72d5bf34')): $__env->markAsRenderedOnce('4bb80752-d69f-4d87-8854-b5bb72d5bf34'); ?>
    <?php if (isset($component)) { $__componentOriginala0d286332d7c052588567c9c0851b512 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0d286332d7c052588567c9c0851b512 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu','data' => ['modular' => $modular,'iconRight' => ''.e($iconRight).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modular' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($modular),'icon_right' => ''.e($iconRight).'']); ?>
         <?php $__env->slot('trigger', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => ''.e($lightIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-600 hover:text-primary-500 dark:!text-dark-500 dark:hover:text-dark-300 stroke-2 theme-light hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($lightIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-600 hover:text-primary-500 dark:!text-dark-500 dark:hover:text-dark-300 stroke-2 theme-light hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => ''.e($darkIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-400 hover:text-primary-500 dark:!text-dark-500 dark:hover:!text-dark-400 stroke-2 theme-dark hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($darkIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-400 hover:text-primary-500 dark:!text-dark-500 dark:hover:!text-dark-400 stroke-2 theme-dark hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => ''.e($systemIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-400 hover:text-primary-500 dark:!text-dark-500 dark:hover:!text-dark-400 stroke-2 theme-system hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($systemIcon).'','type' => ''.e($iconType).'','dir' => ''.e($iconDir).'','class' => 'text-primary-400 hover:text-primary-500 dark:!text-dark-500 dark:hover:!text-dark-400 stroke-2 theme-system hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
        <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => ['onclick' => 'chooseTheme(\'light\')','icon' => ''.e($lightIcon).'','iconCss' => 'stroke-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'chooseTheme(\'light\')','icon' => ''.e($lightIcon).'','icon_css' => 'stroke-2']); ?>
            <?php echo e($lightText); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => ['onclick' => 'chooseTheme(\'dark\')','icon' => ''.e($darkIcon).'','iconCss' => 'stroke-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'chooseTheme(\'dark\')','icon' => ''.e($darkIcon).'','icon_css' => 'stroke-2']); ?>
            <?php echo e($darkText); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.dropmenu-item','data' => ['onclick' => 'chooseTheme(\'system\')','icon' => ''.e($systemIcon).'','iconCss' => 'stroke-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::dropmenu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'chooseTheme(\'system\')','icon' => ''.e($systemIcon).'','icon_css' => 'stroke-2']); ?>
            <?php echo e($systemText); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $attributes = $__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__attributesOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd)): ?>
<?php $component = $__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd; ?>
<?php unset($__componentOriginalb1f3b4b5c6291b7a6c73e0a2532236fd); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $attributes = $__attributesOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__attributesOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0d286332d7c052588567c9c0851b512)): ?>
<?php $component = $__componentOriginala0d286332d7c052588567c9c0851b512; ?>
<?php unset($__componentOriginala0d286332d7c052588567c9c0851b512); ?>
<?php endif; ?>
    <script>
        const chooseTheme = (theme) => {
            theme = (theme !== undefined) ? theme : 'system';
            addToStorage('theme', theme);
            if (theme === 'dark' || theme === 'system') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }

            hide('.theme-dark');
            hide('.theme-light');
            hide('.theme-system');
            unhide(`.theme-${theme}`);
        }
        chooseTheme(getFromStorage('theme'));

        // Listen for changes in the system theme
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (event) => {
            chooseTheme(event.matches ? 'dark' : 'light');
        });
    </script>
<?php endif; ?><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\theme-switcher.blade.php ENDPATH**/ ?>