<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="utf-8">
    <title><?php echo e($settings->website_name); ?></title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="Cartzilla - قالب التجارة الإلكترونية Bootstrap">
    <meta name="keywords" content="bootstrap, متجر, تجارة إلكترونية, سوق, حديث, استجابة, عمل, موبايل, bootstrap, html5, css3, js, معرض, شريط تمرير, لمسة, إبداعي, نظيف">
    <meta name="author" content="Createx Studio">
    <!-- Viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('storage/' . ($settings->icon))); ?>">
    <link rel="mask-icon" color="#fe6a6a" href="<?php echo e(asset('safari-pinned-tab.svg')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.css')); ?>"/>
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/tiny-slider/dist/tiny-slider.css')); ?>"/>
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/theme.min.css')); ?>">
    <!-- Material Icons for delete button -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
      .icon-button {
          border: none;
          background: none;
          color: #dc3545; /* Red color for the delete button */
          cursor: pointer;
          font-size: 24px;
          padding: 0;
      }
      .icon-button:hover {
        color: #c82333;
      }
      .avatar {
          width: 90px; /* Adjust size as needed */
          height: 90px;
          border-radius: 50%;
          margin-right: 10px;
      }
      .d-flex {
        display: flex;
        align-items: center;
      }
    </style>
</head>

<body class="handheld-toolbar-enabled">
    <!-- Google Tag Manager (noscript)-->
    <noscript>
      <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-WKV3GT5" height="0" width="0" style="display: none; visibility: hidden;"></iframe>
    </noscript>
    <!-- Sign in / sign up modal-->
    <?php echo $__env->make('Includes.signin_signup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="page-wrapper">
        <!-- Navbar for NFT Marketplace demo-->
        <?php echo $__env->make('Includes.account_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('Includes.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container mb-5 pb-3">
            <div class="bg-light shadow-lg rounded-3 overflow-hidden">
                <div class="row">
                    <!-- Sidebar-->
                    <?php echo $__env->make('Includes.leftSideMenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- Content-->
                    <section class="col-lg-9 pt-lg-4 pb-4 mb-3">
                        <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
                            <h1 class="h3 mb-4 pt-2 text-center text-sm-end">إعدادات الملف الشخصي</h1>
                            <div class="bg-secondary rounded-3 p-4 mb-4 text-center text-sm-start">
                                <div class="d-flex flex-sm-row flex-column align-items-sm-start align-items-center">
                                    <!-- عرض صورة الملف الشخصي للمستخدم -->
                                    <div class="d-flex align-items-center">
                                        <img class="avatar" src="<?php echo e(Auth::user()->image ? asset('storage/' . Auth::user()->image) : asset('img/nft/vendor/avatar-square.jpg')); ?>" alt="الصورة">
                                        <!-- Delete button for profile image -->
                                        <?php if(Auth::user()->image): ?>
                                            <form action="<?php echo e(route('deleteAvatar')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                <button type="submit" class="icon-button" title="حذف الصورة">
                                                    <i class="material-icons">delete</i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <!-- نموذج لتحديث بيانات المستخدم، بما في ذلك الصورة الرمزية -->
                            <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row gy-3 mb-4 pb-md-3 mb-2">
                                    <div class="col-sm-6">
                                        <label class="form-label" for="profile-name">الاسم الكامل</label>
                                        <input class="form-control" id="profile-name" type="text" value="<?php echo e(Auth::user()->user_name); ?>" name="user_name">
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="profile-phone">الهاتف</label>
                                        <input class="form-control" id="profile-phone" type="text" value="<?php echo e(Auth::user()->phone); ?>" name="phone">
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="profile-email">البريد الإلكتروني</label>
                                        <input class="form-control" id="profile-email" type="email" value="<?php echo e(Auth::user()->email); ?>" name="email">
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label" for="profile-avatar">الصورة الرمزية</label>
                                        <input class="form-control" id="profile-avatar" type="file" name="image">
                                    </div>
                                </div>
                                <div class="d-flex flex-sm-row flex-column">
                                    <button class="btn btn-accent" type="submit">تحديث الملف الشخصي</button>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </main>
    <!-- Footer-->
    <?php echo $__env->make('Includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Toolbar for handheld devices (NFT Marketplace)-->
    <?php echo $__env->make('includes.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Back To Top Button-->
    <a class="btn-scroll-top" href="#top" data-scroll>
        <span class="btn-scroll-top-tooltip text-muted fs-sm me-2">أعلى</span>
        <i class="btn-scroll-top-icon ci-arrow-up"></i>
    </a>
    <!-- Vendor scripts: js libraries and plugins-->
    <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')); ?>"></script>
    <!-- Main theme script-->
    <script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>
    <!-- SweetAlert2 -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>

</html>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\resources\views/dashboard.blade.php ENDPATH**/ ?>