<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    // determines what type of datepicker to show. Available options: single, range
    'type' => 'single',

    // name of the datepicker. This name is used when posting the form with the datepicker
    'name' => 'bw-datepicker',

    // default date to fill in to the datepicker. Defaults to today. Set to blank to display no default
    'default_date' => '',
    'defaultDate' => '',

    // date format.. default is yyyy-mm-dd
    // accepted formats are yyyy-mm-dd, mm-dd-yyyy, dd-mm-yyyy, D d M, Y
    'format' => config('bladewind.datepicker.format', 'yyyy-mm-dd'),

    // text to display in the label that identifies the input field
    'label' => '',

    // placeholder text to display if datepicker is empty
    'placeholder' => 'Select a date',

    // is the value of the date field required? used for form validation. default is false
    'required' => false,

    // should the datepicker include a timepicker. The timepicker is hidden by default
    'with_time' => config('bladewind.datepicker.with_time', false),
    'withTime' => config('bladewind.datepicker.with_time', false),

    // when timepicker is included, what should the time hours be displayed as. Default is 12-hour format
    // available options are 12, 24
    'hours_as' => config('bladewind.datepicker.hours_as', 12),
    'hoursAs' => config('bladewind.datepicker.hours_as', 12),

    // what format should the time be displayed in
    'time_format' => 'hh:mm',
    'timeFormat' => 'hh:mm',

    // when the timepicker is included, should the time be displayed with seconds. Default is false
    'show_seconds' => false,
    'showSeconds' => false,

    //----------- used for range datepickers ----------------------------------
    // what should be the default date for the from date
    'default_date_from' => '',
    'defaultDateFrom' => '',

    // what should be the default date for the to date
    'default_date_to' => '',
    'defaultDateTo' => '',

    // what label should be displayed for the from date. Default is 'From'
    'date_from_label' => 'From',
    'dateFromLabel' => 'From',

    // what label should be displayed for the to date. Default is 'To'
    'date_to_label' => 'To',
    'dateToLabel' => 'To',

    // what names should be used for the from date. Default is 'start_date'
    'date_from_name' => 'start_date',
    'dateFromName' => 'start_date',

    // what name should be displayed for the to date. Default is 'end_date'
    'date_to_name' => 'end_date',
    'dateToName' => 'end_date',

    // should validation be turned on for the range picker
    'validate' => false,

    // should the error message be displayed inline instead of in the notification component
    // ensure you have the <-bladewind::notification /> component in your page if you do not
    // want to display the error inline
    'show_error_inline' => false,

    // validation message to display if there is an error with the range picker selection
    'validation_message' => 'Your end date cannot be less than your start date',

    // custom function to call when the datepicker loses focus
    'onblur' => '',

    'tabindex' => -1,

    // first day of the week
    'week_starts' => 'sunday',

    // any extra classes for the datepicker
    'class' => '',

    // should the datepicker use a placeholder instead of the labels when type="range"
    'use_placeholder' => false,

    // show the range pickers be stacked vertically
    'stacked' => false,

    // size of the input field
    'size' => 'medium'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    // determines what type of datepicker to show. Available options: single, range
    'type' => 'single',

    // name of the datepicker. This name is used when posting the form with the datepicker
    'name' => 'bw-datepicker',

    // default date to fill in to the datepicker. Defaults to today. Set to blank to display no default
    'default_date' => '',
    'defaultDate' => '',

    // date format.. default is yyyy-mm-dd
    // accepted formats are yyyy-mm-dd, mm-dd-yyyy, dd-mm-yyyy, D d M, Y
    'format' => config('bladewind.datepicker.format', 'yyyy-mm-dd'),

    // text to display in the label that identifies the input field
    'label' => '',

    // placeholder text to display if datepicker is empty
    'placeholder' => 'Select a date',

    // is the value of the date field required? used for form validation. default is false
    'required' => false,

    // should the datepicker include a timepicker. The timepicker is hidden by default
    'with_time' => config('bladewind.datepicker.with_time', false),
    'withTime' => config('bladewind.datepicker.with_time', false),

    // when timepicker is included, what should the time hours be displayed as. Default is 12-hour format
    // available options are 12, 24
    'hours_as' => config('bladewind.datepicker.hours_as', 12),
    'hoursAs' => config('bladewind.datepicker.hours_as', 12),

    // what format should the time be displayed in
    'time_format' => 'hh:mm',
    'timeFormat' => 'hh:mm',

    // when the timepicker is included, should the time be displayed with seconds. Default is false
    'show_seconds' => false,
    'showSeconds' => false,

    //----------- used for range datepickers ----------------------------------
    // what should be the default date for the from date
    'default_date_from' => '',
    'defaultDateFrom' => '',

    // what should be the default date for the to date
    'default_date_to' => '',
    'defaultDateTo' => '',

    // what label should be displayed for the from date. Default is 'From'
    'date_from_label' => 'From',
    'dateFromLabel' => 'From',

    // what label should be displayed for the to date. Default is 'To'
    'date_to_label' => 'To',
    'dateToLabel' => 'To',

    // what names should be used for the from date. Default is 'start_date'
    'date_from_name' => 'start_date',
    'dateFromName' => 'start_date',

    // what name should be displayed for the to date. Default is 'end_date'
    'date_to_name' => 'end_date',
    'dateToName' => 'end_date',

    // should validation be turned on for the range picker
    'validate' => false,

    // should the error message be displayed inline instead of in the notification component
    // ensure you have the <-bladewind::notification /> component in your page if you do not
    // want to display the error inline
    'show_error_inline' => false,

    // validation message to display if there is an error with the range picker selection
    'validation_message' => 'Your end date cannot be less than your start date',

    // custom function to call when the datepicker loses focus
    'onblur' => '',

    'tabindex' => -1,

    // first day of the week
    'week_starts' => 'sunday',

    // any extra classes for the datepicker
    'class' => '',

    // should the datepicker use a placeholder instead of the labels when type="range"
    'use_placeholder' => false,

    // show the range pickers be stacked vertically
    'stacked' => false,

    // size of the input field
    'size' => 'medium'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $default_date = $defaultDate;
    $with_time = filter_var($with_time, FILTER_VALIDATE_BOOLEAN);
    $withTime = filter_var($withTime, FILTER_VALIDATE_BOOLEAN);
    if($withTime) $with_time = $withTime;
    $hours_as = $hoursAs;
    $time_format = $timeFormat;
    $show_seconds = filter_var($show_seconds, FILTER_VALIDATE_BOOLEAN);
    $showSeconds = filter_var($showSeconds, FILTER_VALIDATE_BOOLEAN);
    if($showSeconds) $show_seconds = $showSeconds;
    $default_date_from = $defaultDateFrom;
    $default_date_to = $defaultDateTo;
    $date_from_label = $dateFromLabel;
    $date_to_label = $dateToLabel;
    $date_from_name = $dateFromName;
    $date_to_name = $dateToName;
    $required = filter_var($required, FILTER_VALIDATE_BOOLEAN);
    $validate = filter_var($validate, FILTER_VALIDATE_BOOLEAN);
    $show_error_inline = filter_var($show_error_inline, FILTER_VALIDATE_BOOLEAN);
    $use_placeholder = filter_var($use_placeholder, FILTER_VALIDATE_BOOLEAN);
    $stacked = filter_var($stacked, FILTER_VALIDATE_BOOLEAN);
    //--------------------------------------------------------
    $name = preg_replace('/[\s-]/', '_', $name);
    $default_date = ($default_date != '') ? $default_date : '';
    $js_function = ($validate) ? "compareDates('$date_from_name', '$date_to_name', '$validation_message', '$show_error_inline')" : $onblur;
    $week_starts = str_replace('day', '', ((in_array($week_starts, ['sun','sunday','mon','monday'])) ? $week_starts : 'sunday'));
?>
<style>
    [x-cloak] {
        display: none !important;
    }
</style>
<?php if($type == 'single'): ?>
    <div x-data="app('<?php echo e($default_date); ?>', '<?php echo e(strtoupper($format)); ?>', '<?php echo e($week_starts); ?>')"
         x-init="[initDate(), getNoOfDays()]" x-cloak>
        <div class="relative w-full">
            <input
                    type="hidden"
                    x-ref="date"
                    :value="datepickerValue"
                    value="<?php echo e($default_date); ?>"/>

            <?php if (isset($component)) { $__componentOriginal399ab5ed63addab89395df8c37031002 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal399ab5ed63addab89395df8c37031002 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.input','data' => ['class' => 'bw-datepicker '.e($class).'','xOn:click' => 'showDatepicker = !showDatepicker;','xOn:keydown.escape' => 'showDatepicker = false','xModel' => 'datepickerValue','type' => 'text','id' => 'dtp-'.e($name).'','maxDate' => 'today','name' => ''.e($name).'','xRef' => ''.e($name).'','label' => ''.e(($use_placeholder) ? '' : $label).'','placeholder' => ''.e($placeholder).'','onblur' => ''.$onblur.'','tabindex' => ''.$tabindex.'','size' => ''.e($size).'','suffix' => 'calendar-days','suffixIsIcon' => 'true','suffixIconDivCss' => 'rtl:!right-[unset] rtl:!left-0','suffixIconCss' => 'text-slate-300','required' => ''.e($required).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bw-datepicker '.e($class).'','x-on:click' => 'showDatepicker = !showDatepicker;','x-on:keydown.escape' => 'showDatepicker = false','x-model' => 'datepickerValue','type' => 'text','id' => 'dtp-'.e($name).'','max_date' => 'today','name' => ''.e($name).'','x-ref' => ''.e($name).'','label' => ''.e(($use_placeholder) ? '' : $label).'','placeholder' => ''.e($placeholder).'','onblur' => ''.$onblur.'','tabindex' => ''.$tabindex.'','size' => ''.e($size).'','suffix' => 'calendar-days','suffix_is_icon' => 'true','suffix_icon_div_css' => 'rtl:!right-[unset] rtl:!left-0','suffix_icon_css' => 'text-slate-300','required' => ''.e($required).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $attributes = $__attributesOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__attributesOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $component = $__componentOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__componentOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>

            <div class="bg-white dark:bg-dark-700 mt-12 p-4 absolute top-0 left-0 z-50 drop-shadow-md dark:border dark:border-dark-600/70 rounded-lg"
                 style="width: 17rem"
                 x-show.transition="showDatepicker" @click.away="showDatepicker = false">
                <div class="flex justify-between items-center bg-primary-500 dark:bg-dark-800/50 p-4 !-mx-4 !-mt-4 mb-4 rounded-tl-lg rounded-tr-lg">
                    <div>
                        <button type="button"
                                class="focus:outline-none focus:shadow-outline transition ease-in-out duration-100 inline-flex cursor-pointer py-1 pr-1 !-ml-1"
                                @click="if (month == 0) {
                    year--;
                    month = 12;
                } month--; getNoOfDays()">
                            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'arrow-left','class' => 'size-5 text-white/50 hover:text-white inline-flex rtl:!rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'size-5 text-white/50 hover:text-white inline-flex rtl:!rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                        </button>
                    </div>
                    <div class="text-lg text-white/90 dark:text-gray-100 cursor-default">
                        <span x-text="MONTH_NAMES[month]"></span>
                        <span x-text="year" class="ml-1"></span>
                    </div>
                    <div>
                        <button type="button"
                                class="focus:outline-none focus:shadow-outline transition ease-in-out duration-100 inline-flex cursor-pointer py-1 pl-1 !-mr-1 rounded-full"
                                @click="if (month == 11) {
                    month = 0;
                    year++;
                } else {
                    month++;
                } getNoOfDays()">
                            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'arrow-right','class' => 'size-5 text-white/50 hover:text-white inline-flex rtl:!rotate-180']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'size-5 text-white/50 hover:text-white inline-flex rtl:!rotate-180']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
                        </button>
                    </div>
                </div>

                <div class="flex flex-wrap mb-3 -mx-1">
                    <template x-for="(day, index) in DAYS" :key="index">
                        <div style="width: 14.26%" class="px-0.5">
                            <div x-text="day"
                                 class="text-gray-500 tracking-wide dark:text-gray-400 font-medium text-center text-xs uppercase cursor-default"></div>
                        </div>
                    </template>
                </div>

                <div class="flex flex-wrap -mx-1">
                    <template x-for="blankday in blankdays">
                        <div style="width: 14.28%" class="text-center border p-1 border-transparent text-sm"></div>
                    </template>
                    <template x-for="(date, dateIndex) in no_of_days" :key="dateIndex">
                        <div style="width: 14.28%" class=" mb-1">
                            <div @click="getDateValue(date, '<?php echo e($format); ?>')" x-text="date"
                                 class="cursor-pointer text-center text-sm leading-8 rounded-md transition ease-in-out duration-100"
                                 :class="{
                            'bg-primary-100 dark:bg-dark-800': isToday(date) == true,
                            'text-gray-600 dark:text-gray-100 hover:bg-primary-200 hover:dark:bg-dark-500': isToday(date) == false && isSelectedDate(date) == false,
                            'bg-primary-600 dark:bg-dark-900 text-white hover:bg-opacity-75': isSelectedDate(date) == true }">
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="<?php if(!$stacked): ?> grid  grid-cols-2 gap-2 <?php endif; ?>">
        <div>
            <?php if (isset($component)) { $__componentOriginal98e78a7b239f903403ed2a7d633e9dc0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.datepicker','data' => ['name' => ''.e($date_from_name).'','type' => 'single','placeholder' => ''.e($date_from_label).'','defaultDate' => ''.e($default_date_from??'').'','required' => $required,'stacked' => $stacked,'usePlaceholder' => $use_placeholder,'label' => ''.e($date_from_label).'','weekStarts' => ''.e($week_starts).'','onblur' => ''.e($js_function).'','class' => ''.e($class).'','size' => ''.e($size).'','format' => ''.e($format).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($date_from_name).'','type' => 'single','placeholder' => ''.e($date_from_label).'','default_date' => ''.e($default_date_from??'').'','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($required),'stacked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stacked),'use_placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($use_placeholder),'label' => ''.e($date_from_label).'','week_starts' => ''.e($week_starts).'','onblur' => ''.e($js_function).'','class' => ''.e($class).'','size' => ''.e($size).'','format' => ''.e($format).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0)): ?>
<?php $attributes = $__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0; ?>
<?php unset($__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98e78a7b239f903403ed2a7d633e9dc0)): ?>
<?php $component = $__componentOriginal98e78a7b239f903403ed2a7d633e9dc0; ?>
<?php unset($__componentOriginal98e78a7b239f903403ed2a7d633e9dc0); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginal98e78a7b239f903403ed2a7d633e9dc0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.datepicker','data' => ['name' => ''.e($date_to_name).'','type' => 'single','placeholder' => ''.e($date_to_label).'','defaultDate' => ''.e($default_date_to??'').'','required' => $required,'stacked' => $stacked,'usePlaceholder' => $use_placeholder,'label' => ''.e($date_to_label).'','weekStarts' => ''.e($week_starts).'','onblur' => ''.e($js_function).'','class' => ''.e($class).'','size' => ''.e($size).'','format' => ''.e($format).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($date_to_name).'','type' => 'single','placeholder' => ''.e($date_to_label).'','default_date' => ''.e($default_date_to??'').'','required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($required),'stacked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stacked),'use_placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($use_placeholder),'label' => ''.e($date_to_label).'','week_starts' => ''.e($week_starts).'','onblur' => ''.e($js_function).'','class' => ''.e($class).'','size' => ''.e($size).'','format' => ''.e($format).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0)): ?>
<?php $attributes = $__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0; ?>
<?php unset($__attributesOriginal98e78a7b239f903403ed2a7d633e9dc0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal98e78a7b239f903403ed2a7d633e9dc0)): ?>
<?php $component = $__componentOriginal98e78a7b239f903403ed2a7d633e9dc0; ?>
<?php unset($__componentOriginal98e78a7b239f903403ed2a7d633e9dc0); ?>
<?php endif; ?>
        </div>
        <div class="text-red-500 text-sm -mt-2 mb-3 col-span-2 error-<?php echo e($date_from_name.$date_to_name); ?>"></div>
    </div>
<?php endif; ?>
<?php if (! $__env->hasRenderedOnce('196b982e-8eda-45a3-b06f-f4bd1743acba')): $__env->markAsRenderedOnce('196b982e-8eda-45a3-b06f-f4bd1743acba'); ?>
    <script>
        const january = '<?php echo e(__('bladewind::datepicker.JAN')); ?>';
        const february = '<?php echo e(__('bladewind::datepicker.FEB')); ?>';
        const march = '<?php echo e(__('bladewind::datepicker.MAR')); ?>';
        const april = '<?php echo e(__('bladewind::datepicker.APR')); ?>';
        const may = '<?php echo e(__('bladewind::datepicker.MAY')); ?>';
        const june = '<?php echo e(__('bladewind::datepicker.JUN')); ?>';
        const july = '<?php echo e(__('bladewind::datepicker.JUL')); ?>';
        const august = '<?php echo e(__('bladewind::datepicker.AUG')); ?>';
        const september = '<?php echo e(__('bladewind::datepicker.SEP')); ?>';
        const october = '<?php echo e(__('bladewind::datepicker.OCT')); ?>';
        const november = '<?php echo e(__('bladewind::datepicker.NOV')); ?>';
        const december = '<?php echo e(__('bladewind::datepicker.DEC')); ?>';

        const monday = '<?php echo e(__('bladewind::datepicker.MON')); ?>';
        const tuesday = '<?php echo e(__('bladewind::datepicker.TUE')); ?>';
        const wednesday = '<?php echo e(__('bladewind::datepicker.WED')); ?>';
        const thursday = '<?php echo e(__('bladewind::datepicker.THU')); ?>';
        const friday = '<?php echo e(__('bladewind::datepicker.FRI')); ?>';
        const saturday = '<?php echo e(__('bladewind::datepicker.SAT')); ?>';
        const sunday = '<?php echo e(__('bladewind::datepicker.SUN')); ?>';

        const MONTH_NAMES = [
            january, february, march, april, may, june, july, august,
            september, october, november, december,
        ];
        const MONTH_SHORT_NAMES = [
            january.substring(0, 3), february.substring(0, 3), march.substring(0, 3),
            april.substring(0, 3), may.substring(0, 3), june.substring(0, 3), july.substring(0, 3),
            august.substring(0, 3), september.substring(0, 3), october.substring(0, 3),
            november.substring(0, 3), december.substring(0, 3)
        ];
        const DAYS = [<?php if($week_starts == 'sun'): ?> sunday.substring(0, 3), <?php endif; ?>
        monday.substring(0, 3), tuesday.substring(0, 3), wednesday.substring(0, 3),
            thursday.substring(0, 3), friday.substring(0, 3), saturday.substring(0, 3) <?php if($week_starts == 'mon'): ?> , sunday.substring(0, 3) <?php endif; ?>
        ];
    </script>
    <script src="<?php echo e(asset('vendor/bladewind/js/datepicker.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\datepicker.blade.php ENDPATH**/ ?>