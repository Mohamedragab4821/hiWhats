<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'status' => 'pending',
    'date' => '',
    'date_css' => '',
    'label' => '',
    'content' => '',
    'last' => false,
    'avatar' => '',
    'avatar_css' => '',
    'align_left' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'status' => 'pending',
    'date' => '',
    'date_css' => '',
    'label' => '',
    'content' => '',
    'last' => false,
    'avatar' => '',
    'avatar_css' => '',
    'align_left' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php foreach (([
    'stacked' => config('bladewind.timeline.stacked', false),
    'completed' => false,
    'color' => 'gray',
    'anchor' => 'small',
    'anchor_css' => '',
    'icon' => '',
    'icon_css' => '',
    'date_css' => '',
    'position' => 'center',
]) as $__key => $__value) {
    $__consumeVariable = is_string($__key) ? $__key : $__value;
    $$__consumeVariable = is_string($__key) ? $__env->getConsumableComponentData($__key, $__value) : $__env->getConsumableComponentData($__value);
} ?>
<?php
    $stacked = filter_var($stacked, FILTER_VALIDATE_BOOLEAN);
    $completed = filter_var($completed, FILTER_VALIDATE_BOOLEAN);
    $completed = ($status !== 'pending') || $completed;
    $last = filter_var($last, FILTER_VALIDATE_BOOLEAN);
    $align_left = filter_var($align_left, FILTER_VALIDATE_BOOLEAN);
    $content = (!empty($label)) ? $label : $content;
    $anchor_size_css = ($anchor == 'big') ? "h-8 w-8" : "h-3 w-3";
    $anchor_css = sprintf('%s ' .(($completed) ? "bg-$color-500 " : "border-2 border-$color-500/50 "), $anchor_size_css);
    $content_css = ($stacked) ? 'pt-0 pb-6' : (($anchor=='big') ? 'pt-2 pb-10' : 'pb-6');
    $date_css = (($stacked) ? 'pt-0 ' : (($anchor=='big') ? 'pt-2.5 ' : '')) . $date_css;
    $icon = ($completed && $anchor == 'big' && empty($icon)) ? 'check' : $icon;
    $icon_css = (($completed && $anchor == 'big') ? 'text-white ' : "!text-$color-500 opacity-70 ") . $icon_css;
    if(!empty($avatar)) $anchor = "big";
?>
<div class="flex">
    <div class="<?php if($position!=='left'): ?> grow w-1/2 <?php else: ?> <?php if(!$stacked): ?> min-w-28 <?php else: ?> !pr-0 <?php endif; ?> <?php endif; ?> text-right pr-5 text-sm">
        <?php if(!$stacked || ($stacked && $align_left)): ?>
            <div class="font-semibold text-slate-600 dark:text-dark-500 min-w-28 <?php echo e($date_css); ?>"><?php echo $date; ?></div>
            <?php if($align_left): ?>
                <div class="leading-6 <?php echo e($content_css); ?>">
                    <?php echo $content; ?>

                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <div class="flex flex-col <?php if(!$last): ?> justify-center <?php endif; ?> items-center">
        <div class="rounded-full mt-1 inline-flex items-center justify-center <?php echo e($anchor_css); ?>">
            <?php if(!empty($avatar)): ?>
                <?php if (isset($component)) { $__componentOriginal0ad07d55369c3f142811e8f2e87d048d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.avatar','data' => ['image' => $avatar,'size' => 'small','class' => ''.e($avatar_css).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($avatar),'size' => 'small','class' => ''.e($avatar_css).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $attributes = $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $component = $__componentOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
            <?php elseif(!empty($icon)): ?>
                <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => $icon,'class' => '!w-5 !h-5 '.e($icon_css).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => '!w-5 !h-5 '.e($icon_css).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if(!$last): ?>
            <div class="bg-<?php echo e($color); ?>-500 <?php if(!$completed): ?> opacity-30 <?php endif; ?> grow w-[2px] my-1.5"></div>
        <?php endif; ?>
    </div>

    <div class="grow w-1/2 pl-5 space-y-1 text-sm">
        <?php if(!$align_left): ?>
            <?php if($stacked): ?>
                <div class="font-bold text-slate-600 dark:text-dark-500 <?php echo e($date_css); ?>"><?php echo $date; ?></div>
            <?php endif; ?>
            <div class="leading-6 <?php echo e($content_css); ?>">
                <?php echo $content; ?>

            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\timeline.blade.php ENDPATH**/ ?>