<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from cartzilla.createx.studio/nft-account-settings.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Aug 2022 18:19:25 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title><?php echo e($settings->website_name); ?> </title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="Cartzilla - Bootstrap E-commerce Template">
    <meta name="keywords" content="bootstrap, shop, e-commerce, market, modern, responsive,  business, mobile, bootstrap, html5, css3, js, gallery, slider, touch, creative, clean">
    <meta name="author" content="Createx Studio">
    <!-- Viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon and Touch Icons-->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('storage/' . ($settings->logo))); ?>">
    <link rel="mask-icon" color="#fe6a6a" href="<?php echo e(asset('safari-pinned-tab.svg')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <!-- Vendor Styles including: Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.css')); ?>"/>
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('vendor/tiny-slider/dist/tiny-slider.css')); ?>"/>
    <!-- Main Theme Styles + Bootstrap-->
    <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/theme.min.css')); ?>">

    <style>
        .btn-close {
        position: absolute;
        top: 2rem; /* المسافة من الأعلى */
        left: 2rem; /* المسافة من اليسار */
        z-index: 1050; /* التأكد من بقاء الزر فوق المحتوى */
    }
    </style>
    <!-- Google Tag Manager-->

  </head>
  <!-- Body-->
  <body class="handheld-toolbar-enabled">
    <!-- Google Tag Manager (noscript)-->
    <noscript>
      <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-WKV3GT5" height="0" width="0" style="display: none; visibility: hidden;"></iframe>
    </noscript>
    <!-- Sign in / sign up modal-->
    <?php echo $__env->make('Includes.signin_signup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="page-wrapper">
      <!-- Navbar for NFT Marketplace demo-->
      <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->
      <?php echo $__env->make('Includes.account_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('Includes.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="container mb-5 pb-3">

        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
          <div class="row">
            <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

            <!-- Sidebar-->
            <?php echo $__env->make('Includes.leftSideMenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Content-->
            <section class="col-lg-8">
              <!-- Toolbar-->
              <div class="d-none d-lg-flex justify-content-between align-items-center pt-lg-3 pb-4 pb-lg-5 mb-lg-3">
                <h6 class="fs-base text-light mb-0">List of items you added to wishlist:</h6><a class="btn btn-primary btn-sm" href="#productt-modal" data-bs-toggle="modal">إضافة منتج</a>
              </div>
              <form action="<?php echo e(route('Product.search')); ?>" method="GET" class="d-flex align-items-center">
                <input type="text" name="search" placeholder="ابحث..." class="form-control me-2">
                <button type="submit" class="btn btn-primary">بحث</button>
            </form>
              <div class="modal fade" id="productt-modal" tabindex="-1" role="dialog">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header bg-secondary">
                        <ul class="nav nav-tabs card-header-tabs" role="tablist">
                          <li class="nav-item"><a class="nav-link fw-medium active" href="#signin-tab" data-bs-toggle="tab" role="tab" aria-selected="true">إضافة منتج</a></li>
                        </ul>
                        <img src="" alt="">
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body tab-content py-4">
                        <form class="needs-validation tab-pane fade show active" autocomplete="off" novalidate id="product-form" action="<?php echo e(route('storeProduct')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- اسم المنتج -->
                            <div class="mb-3">
                                <label class="form-label" for="product_name">اسم المنتج</label>
                                <input class="form-control" type="text" id="product_name" name="product_name" placeholder="أدخل اسم المنتج" required>
                                <div class="invalid-feedback">يرجى تقديم اسم منتج صالح.</div>
                            </div>

                            <!-- اسم التصنيف -->
                            <div class="mb-3">
                                <label class="form-label" for="category_name">اسم التصنيف</label>
                                <select class="form-control" id="category_id" name="category_id" required>
                                    <option value="" disabled selected>اختر تصنيفًا</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback">يرجى اختيار تصنيف صالح.</div>
                            </div>

                            <!-- سعر المنتج -->
                            <div class="mb-3">
                                <label class="form-label" for="product_salary">سعر المنتج</label>
                                <input class="form-control" type="number" id="product_salary" name="product_salary" placeholder="أدخل سعر المنتج" required>
                                <div class="invalid-feedback">يرجى تقديم سعر منتج صالح.</div>
                            </div>

                            <!-- الوصف -->
                            <div class="mb-3">
                                <label class="form-label" for="description">الوصف</label>
                                <textarea class="form-control" id="description" name="description" rows="3" placeholder="أدخل وصف المنتج" required></textarea>
                                <div class="invalid-feedback">يرجى تقديم وصف صالح.</div>
                            </div>

                            <!-- مدة الصلاحية -->
                            <div class="mb-3">
                                <label class="form-label" for="Duration_of_righteousness">مدة الصلاحية</label>
                                <input class="form-control" type="text" id="Duration_of_righteousness" name="Duration_of_righteousness" placeholder="أدخل مدة الصلاحية" required>
                                <div class="invalid-feedback">يرجى تقديم مدة صلاحية صالحة.</div>
                            </div>

                            <!-- صورة المنتج -->
                            <div class="mb-3">
                                <label class="form-label" for="Product_img">صورة المنتج</label>
                                <input class="form-control" type="file" id="Product_img" name="Product_img" required>
                                <div class="invalid-feedback">يرجى تحميل صورة المنتج.</div>
                            </div>

                            <!-- زر الإضافة -->
                            <button class="btn btn-primary btn-shadow d-block w-100" type="submit">إضافة المنتج</button>
                        </form>


                      </div>
                    </div>
                  </div>
              </div>
              <!-- Wishlist-->
              <!-- Item-->

              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="d-sm-flex justify-content-between mt-lg-4 mb-4 pb-3 pb-sm-2 border-bottom">
                  <div class="d-block d-sm-flex align-items-start text-center text-sm-start">
                      <a class="d-block flex-shrink-0 mx-auto me-sm-4" style="width: 10rem;">
                          <img src="<?php echo e(asset('storage/' . $product->Product_img)); ?>" alt="Product">
                      </a>
                      <div class="pt-2">
                          <h3 class="product-title fs-base mb-2">
                              <a><?php echo e($product->product_name); ?></a>
                          </h3>
                          <div class="fs-sm">
                              <span class="text-muted me-2"> وصــف : </span> <?php echo e($product->description); ?>

                          </div>
                          <div class="fs-sm">
                              <span class="text-muted me-2">تاريخ الانتهاء :</span><?php echo e($product->Duration_of_righteousness); ?>

                          </div>
                          <div class="fs-lg text-accent pt-2"><?php echo e($product->product_salary); ?></div>
                      </div>
                  </div>
                  <div class="pt-2 ps-sm-3 mx-auto mx-sm-0 text-center">
                      <form action="<?php echo e(route('deleteProduct', ['product_id' => $product->product_id])); ?>" method="POST" style="display: inline;">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="btn btn-outline-danger btn-sm" type="submit"><i class="ci-trash me-2"></i>إزالة</button>
                      </form>
                          <!-- Edit Button -->
                          <button
    class="btn btn-outline-primary btn-sm"
    type="button"
    data-bs-toggle="modal"
    data-bs-target="#product-modal"
    data-product-id="<?php echo e($product->product_id); ?>"
    data-product-name="<?php echo e($product->product_name); ?>"
    data-category-id="<?php echo e($product->category_id); ?>"
    data-product-salary="<?php echo e($product->product_salary); ?>"
    data-description="<?php echo e($product->description); ?>"
    data-duration="<?php echo e($product->Duration_of_righteousness); ?>"
    data-product-img="<?php echo e($product->Product_img); ?>">
    <i class="ci-edit me-2"></i>تعديل
</button>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        var productModal = document.getElementById('product-modal');

        productModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget; // Button that triggered the modal

            // Extract data attributes from the button
            var productId = button.getAttribute('data-product-id');
            var productName = button.getAttribute('data-product-name');
            var categoryId = button.getAttribute('data-category-id'); // This should be the category ID
            var productSalary = button.getAttribute('data-product-salary');
            var description = button.getAttribute('data-description');
            var duration = button.getAttribute('data-duration');
            var productImg = button.getAttribute('data-product-img');

            // Update the form inputs in the modal
            var modalForm = productModal.querySelector('form');
            modalForm.action = "/profileSetting/productMangement/edit-product/" + productId; // Set form action with the product ID

            modalForm.querySelector('#product_name').value = productName;
            modalForm.querySelector('#product_salary').value = productSalary;
            modalForm.querySelector('#description').value = description;
            modalForm.querySelector('#Duration_of_righteousness').value = duration;

            // Set the selected category
            var categorySelect = modalForm.querySelector('#category_id');

            // Loop through options to find the one that matches the categoryId
            Array.from(categorySelect.options).forEach(function(option) {
                if (option.value === categoryId) {
                    option.selected = true; // Set the matching option as selected
                }
            });

            // If you want to display the image in the form, you can use an <img> tag with an ID
            var imgElement = modalForm.querySelector('#Product_img_display');
            if (imgElement) {
                imgElement.src = "/storage/" + productImg;
            }
        });
    });
    </script>



                  </div>

              </div>
              <!-- Modal for editing product -->
<div class="modal fade" id="product-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-secondary">
                <h5 class="modal-title">تعديل المنتج</h5>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" autocomplete="off" novalidate id="product-form" action="<?php echo e(route('editProduct', ['product_id' => $product->product_id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <!-- اسم المنتج -->
                    <div class="mb-3">
                        <label class="form-label" for="product_name">اسم المنتج</label>
                        <input class="form-control" type="text" id="product_name" name="product_name" value="<?php echo e(old('product_name', $product->product_name)); ?>" required>
                        <div class="invalid-feedback">يرجى تقديم اسم منتج صالح.</div>
                    </div>

                    <!-- اسم التصنيف -->
                    <div class="mb-3">
                        <label class="form-label" for="category_id">اسم التصنيف</label>
                        <select class="form-control" id="category_id" name="category_id" required>
                            <option value="" disabled>اختر تصنيفًا</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category_id); ?>"
                                    <?php echo e($category->category_id == $product->category_id ? 'selected' : ''); ?>>
                                    <?php echo e($category->category_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">يرجى اختيار تصنيف صالح.</div>
                    </div>

                    <!-- سعر المنتج -->
                    <div class="mb-3">
                        <label class="form-label" for="product_salary">سعر المنتج</label>
                        <input class="form-control" type="number" id="product_salary" name="product_salary" value="<?php echo e(old('product_salary', $product->product_salary)); ?>" required>
                        <div class="invalid-feedback">يرجى تقديم سعر منتج صالح.</div>
                    </div>

                    <!-- الوصف -->
                    <div class="mb-3">
                        <label class="form-label" for="description">الوصف</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required><?php echo e(old('description', $product->description)); ?></textarea>
                        <div class="invalid-feedback">يرجى تقديم وصف صالح.</div>
                    </div>

                    <!-- مدة الصلاحية -->
                    <div class="mb-3">
                        <label class="form-label" for="Duration_of_righteousness">مدة الصلاحية</label>
                        <input class="form-control" type="text" id="Duration_of_righteousness" name="Duration_of_righteousness" value="<?php echo e(old('Duration_of_righteousness', $product->Duration_of_righteousness)); ?>" required>
                        <div class="invalid-feedback">يرجى تقديم مدة صلاحية صالحة.</div>
                    </div>

                    <!-- صورة المنتج -->
                    <div class="mb-3">
                        <label class="form-label" for="Product_img">صورة المنتج</label>
                        <input class="form-control" type="file" id="Product_img" name="Product_img">
                        <div class="invalid-feedback">يرجى تحميل صورة المنتج.</div>
                    </div>

                    <!-- زر التحديث -->
                    <button class="btn btn-primary btn-shadow d-block w-100" type="submit">تحديث المنتج</button>
                </form>
            </div>
        </div>
    </div>
</div>




          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              <!-- Item-->

            </section>
            <hr>
             <!-- Pagination-->
             <nav class="d-flex justify-content-center pt-2 mb-4" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item <?php echo e($products->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">
                            <i class="ci-arrow-right me-2"></i>السابق
                        </a>
                    </li>
                </ul>
                <ul class="pagination">
                    <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
                <ul class="pagination">
                    <li class="page-item <?php echo e($products->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">
                            التالي<i class="ci-arrow-left ms-2"></i>
                        </a>
                    </li>
                </ul>
            </nav>


          </div>
        </div>
      </div>
    </main>
    <!-- Footer-->
    <?php echo $__env->make('Includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Toolbar for handheld devices (NFT Marketplace)-->
    <?php echo $__env->make('includes.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Back To Top Button--><a class="btn-scroll-top" href="#top" data-scroll><span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span><i class="btn-scroll-top-icon ci-arrow-up">   </i></a>
    <!-- Vendor scrits: js libraries and plugins-->
    <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')); ?>"></script>
    <!-- Main theme script-->
    <script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>

  </body>

<!-- Mirrored from cartzilla.createx.studio/nft-account-settings.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Aug 2022 18:19:25 GMT -->
</html>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\resources\views/ProductMangement.blade.php ENDPATH**/ ?>