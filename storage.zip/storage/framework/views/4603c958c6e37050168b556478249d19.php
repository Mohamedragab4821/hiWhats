<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    // available options are true or false as strings.
    // setting this to true will set this tab content as the active one
    'active' => false,
    // unique way to identify this tab content using css or javascript
    // this name is used for switching to this content when the tab header is clicked
    'name' => 'tab',
    // additional css to add to the tab content
    // prodbably you'd want to reduce the paddings
    'class' => config('bladewind.tab.content.class', ''),
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    // available options are true or false as strings.
    // setting this to true will set this tab content as the active one
    'active' => false,
    // unique way to identify this tab content using css or javascript
    // this name is used for switching to this content when the tab header is clicked
    'name' => 'tab',
    // additional css to add to the tab content
    // prodbably you'd want to reduce the paddings
    'class' => config('bladewind.tab.content.class', ''),
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php 
    $name = preg_replace('/[\s]/', '-', $name);
    $active = filter_var($active, FILTER_VALIDATE_BOOLEAN);
    $active_css = sprintf(((!$active) ? 'hidden %s' : '%s'), $class);
?>
<div class="atab-content bw-tc-<?php echo e($name); ?> <?php echo e($active_css); ?>">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\tab-content.blade.php ENDPATH**/ ?>