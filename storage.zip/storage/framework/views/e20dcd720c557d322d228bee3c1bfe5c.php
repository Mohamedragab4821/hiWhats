<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([ 
    // unique name for identifying the toggle element
    // useful for checking the value of the toggle when form is submitted
    'name' => 'bw-toggle',
    // label to display next to the toggle element
    'label' => '',
    // the position of the label above. left or right
    'label_position' => config('bladewind.toggle.label_position', 'left'),
    'labelPosition' => config('bladewind.toggle.label_position', 'left'),
    // sets or unsets disabled on the toggle element
    'disabled' => false,
    // sets or unsets checked on the toggle element
    'checked' => false,
    // background color to display when toggle is active
    'color' => 'primary',
    // should the label and toggle element be justified in their parent element?
    'justified' => config('bladewind.toggle.justified', false),
    // how big should the toggle bar be. Options available are thin, thick, thicker
    'bar' => config('bladewind.toggle.bar', 'thick'),
    // javascript function to run when toggle is clicked
    'onclick' => 'javascript:void(0)',
    // css for label
    'class' => '',
    // build size of the bar and circle
    'bar_circle_size' => [
        'thin' => 'w-12 h-3 after:w-5 after:h-5',
        'thick' => 'w-12 h-7 after:w-5 after:h-5',
        'thicker' => 'w-[4.5rem] h-10 after:w-8 after:h-8',
    ],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([ 
    // unique name for identifying the toggle element
    // useful for checking the value of the toggle when form is submitted
    'name' => 'bw-toggle',
    // label to display next to the toggle element
    'label' => '',
    // the position of the label above. left or right
    'label_position' => config('bladewind.toggle.label_position', 'left'),
    'labelPosition' => config('bladewind.toggle.label_position', 'left'),
    // sets or unsets disabled on the toggle element
    'disabled' => false,
    // sets or unsets checked on the toggle element
    'checked' => false,
    // background color to display when toggle is active
    'color' => 'primary',
    // should the label and toggle element be justified in their parent element?
    'justified' => config('bladewind.toggle.justified', false),
    // how big should the toggle bar be. Options available are thin, thick, thicker
    'bar' => config('bladewind.toggle.bar', 'thick'),
    // javascript function to run when toggle is clicked
    'onclick' => 'javascript:void(0)',
    // css for label
    'class' => '',
    // build size of the bar and circle
    'bar_circle_size' => [
        'thin' => 'w-12 h-3 after:w-5 after:h-5',
        'thick' => 'w-12 h-7 after:w-5 after:h-5',
        'thicker' => 'w-[4.5rem] h-10 after:w-8 after:h-8',
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    if ($labelPosition !== $label_position) $label_position = $labelPosition;
    $name = preg_replace('/[\s-]/', '_', $name);
    $disabled = filter_var($disabled, FILTER_VALIDATE_BOOLEAN);
    $checked = filter_var($checked, FILTER_VALIDATE_BOOLEAN);
    $justified = filter_var($justified, FILTER_VALIDATE_BOOLEAN);
    $bar = (!in_array($bar, ['thin', 'thick', 'thicker'])) ? 'thick' : $bar;
    $colour = (!in_array($color, ['primary', 'red', 'yellow', 'green', 'blue', 'pink', 'cyan', 'gray', 'purple', 'orange', 'fuchsia', 'indigo', 'violet'])) ? 'primary' : $color;
    $bar_colour = "peer-checked:bg-$colour-600 after:border-$colour-100";
?>

<label class="relative <?php if(!$justified): ?>inline-flex <?php else: ?> flex justify-between <?php endif; ?> items-center group bw-tgl-<?php echo e($name); ?>">
    <?php if($label_position == 'left' && !empty($label)): ?>
        <span class="pr-4 rtl:pl-4"><?php echo $label; ?></span>
    <?php endif; ?>
    <input type="checkbox" <?php if($checked): ?> checked <?php endif; ?> <?php if($disabled): ?> disabled <?php endif; ?> onclick="<?php echo $onclick; ?>"
           name="<?php echo e($name); ?>"
           class="peer sr-only appearance-none <?php echo e($name); ?>"/>
    <span class="flex items-center flex-shrink-0 p-1 bg-gray-900/10 dark:bg-dark-800/50 rounded-full cursor-pointer
    peer-disabled:opacity-40 rtl:peer-checked:after:-translate-x-full peer-checked:after:translate-x-full transition
    duration-200 ease-in-out after:transition after:duration-200 after:ease-in-out after:bg-white after:shadow-sm after:ring-1 after:ring-slate-700/10
    after:rounded-full bw-tgl-sp-<?php echo e($name); ?> <?php echo e($bar_circle_size[$bar]); ?> <?php echo e($bar_colour); ?> <?php echo e($class); ?>"></span>
    <?php if($label_position=='right' && $label !== ''): ?>
        <span class="pl-4 rtl:pr-4 <?php echo e($class); ?>"><?php echo $label; ?></span>
    <?php endif; ?>
</label><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\toggle.blade.php ENDPATH**/ ?>