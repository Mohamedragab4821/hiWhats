<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    /*
    |-------------------------------------------------------------------------
    | AVATAR COMPONENT (https://bladewindui.com/component/avatar)
    |-------------------------------------------------------------------------
    |
    | this component is different from avatar.blade.php
    | this component serves as a container if you wish to have a group of avatars
    | that need to have the same attributes. You declare them once here, and they
    | cascade to all the individual avatars wrapped in x-bladewind::avatars
    |
     * */
     // size of the avatar
     // available sizes are: tiny | small | medium | regular | big | huge | omg
    'size' => config('bladewind.avatars.size', 'regular'),

    // additional css to apply to the avatars group
    'class' => '',

    // should the avatars have a ring around them
    'show_ring' => config('bladewind.avatars.show_ring', true),

    // should each avatar have a dot indicator
    'dotted' => config('bladewind.avatars.dotted', false),

    // where should the dot indicator be placed: bottom | top
    'dot_position' => config('bladewind.avatars.dot_position', 'bottom'),

    // what should be the colour of the dot indicator
    // accepts all available colours in the BladewindUI palette
    // https://bladewindui.com/customize/colours
    'dot_color' => config('bladewind.avatars.dot_color', 'primary'),

    // indicate how many more avatars are there but hidden +23
    'plus' => null,

    // should the avatars be stacked
    'stacked' => config('bladewind.avatars.stacked', true),

    // how many avatars should be displayed of the total available
    // you can have 20 avatars stacked, but you can opt to display only 10
    // the component will automatically append a. +10
    'show_only' => 0,

    // what happens when user clicks on +23? the default action
    // is to expand to show all avatars ONLY if there are more avatars to display
    // accepts a JS function as a string
    'plus_action' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    /*
    |-------------------------------------------------------------------------
    | AVATAR COMPONENT (https://bladewindui.com/component/avatar)
    |-------------------------------------------------------------------------
    |
    | this component is different from avatar.blade.php
    | this component serves as a container if you wish to have a group of avatars
    | that need to have the same attributes. You declare them once here, and they
    | cascade to all the individual avatars wrapped in x-bladewind::avatars
    |
     * */
     // size of the avatar
     // available sizes are: tiny | small | medium | regular | big | huge | omg
    'size' => config('bladewind.avatars.size', 'regular'),

    // additional css to apply to the avatars group
    'class' => '',

    // should the avatars have a ring around them
    'show_ring' => config('bladewind.avatars.show_ring', true),

    // should each avatar have a dot indicator
    'dotted' => config('bladewind.avatars.dotted', false),

    // where should the dot indicator be placed: bottom | top
    'dot_position' => config('bladewind.avatars.dot_position', 'bottom'),

    // what should be the colour of the dot indicator
    // accepts all available colours in the BladewindUI palette
    // https://bladewindui.com/customize/colours
    'dot_color' => config('bladewind.avatars.dot_color', 'primary'),

    // indicate how many more avatars are there but hidden +23
    'plus' => null,

    // should the avatars be stacked
    'stacked' => config('bladewind.avatars.stacked', true),

    // how many avatars should be displayed of the total available
    // you can have 20 avatars stacked, but you can opt to display only 10
    // the component will automatically append a. +10
    'show_only' => 0,

    // what happens when user clicks on +23? the default action
    // is to expand to show all avatars ONLY if there are more avatars to display
    // accepts a JS function as a string
    'plus_action' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bw-avatars <?php echo e($class); ?>">
    <?php echo e($slot); ?>

    <?php if(is_numeric($plus) && $plus > 0): ?>
        <?php if (isset($component)) { $__componentOriginal0ad07d55369c3f142811e8f2e87d048d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.avatar','data' => ['size' => $size,'image' => '+'.e($plus).'','plusAction' => ''.$plus_action.'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size),'image' => '+'.e($plus).'','plus_action' => ''.$plus_action.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $attributes = $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $component = $__componentOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\avatars.blade.php ENDPATH**/ ?>