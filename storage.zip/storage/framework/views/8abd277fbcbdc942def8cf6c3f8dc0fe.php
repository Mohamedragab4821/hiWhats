<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'onclick' => '',
    'title' => '',
    'href' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'onclick' => '',
    'title' => '',
    'href' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php foreach (([
    'type' => 'primary',
    'color' => '',
    'size' => config('bladewind.button.circle.size', 'regular'),
    'name' => null,
    'can_submit' => false,
    'canSubmit' => false,
    'disabled' => false,
    'tag' => 'button',
    'icon' => '',
    'radius' => 'full',
    'button_text_css' => null,
    'show_focus_ring' => true,
    'outline' => false,
]) as $__key => $__value) {
    $__consumeVariable = is_string($__key) ? $__key : $__value;
    $$__consumeVariable = is_string($__key) ? $__env->getConsumableComponentData($__key, $__value) : $__env->getConsumableComponentData($__value);
} ?>

<?php if($color == 'secondary') $type = 'secondary'; ?>

<?php if (isset($component)) { $__componentOriginal3608e16198bf00bb6a87433895e7f5e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.index','data' => ['color' => $color,'size' => $size,'name' => $name,'canSubmit' => $can_submit,'disabled' => $disabled,'showFocusRing' => $show_focus_ring,'outline' => $outline,'tag' => $tag,'icon' => $icon,'radius' => 'full','buttonTextCss' => $button_text_css,'title' => $title,'type' => $type,'circular' => 'true','onclick' => $onclick,'href' => $href]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($color),'size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name),'can_submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($can_submit),'disabled' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($disabled),'show_focus_ring' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_focus_ring),'outline' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($outline),'tag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tag),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'radius' => 'full','button_text_css' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($button_text_css),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type),'circular' => 'true','onclick' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($onclick),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($href)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $attributes = $__attributesOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__attributesOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9)): ?>
<?php $component = $__componentOriginal3608e16198bf00bb6a87433895e7f5e9; ?>
<?php unset($__componentOriginal3608e16198bf00bb6a87433895e7f5e9); ?>
<?php endif; ?><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\button\circle.blade.php ENDPATH**/ ?>