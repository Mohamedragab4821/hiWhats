<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'number' => '',
    'label_position' => config('bladewind.statistic.label_position', 'top'),
    'labelPosition' => config('bladewind.statistic.label_position', 'top'),
    'icon_position' => config('bladewind.statistic.icon_position', 'left'),
    'iconPosition' => config('bladewind.statistic.icon_position', 'left'),
    'currency_position' => config('bladewind.statistic.currency_position', 'left'),
    'currencyPosition' => config('bladewind.statistic.currency_position', 'left'),
    'label' => '',
    'icon' => '',
    'currency' => config('bladewind.statistic.currency', ''),
    'show_spinner' => false,
    'showSpinner' => false,
    'has_shadow' => config('bladewind.statistic.has_shadow', true),
    'hasShadow' => config('bladewind.statistic.has_shadow', true),
    'hasBorder' => config('bladewind.statistic.has_border', true),
    'class' => '',
    'number_css' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'number' => '',
    'label_position' => config('bladewind.statistic.label_position', 'top'),
    'labelPosition' => config('bladewind.statistic.label_position', 'top'),
    'icon_position' => config('bladewind.statistic.icon_position', 'left'),
    'iconPosition' => config('bladewind.statistic.icon_position', 'left'),
    'currency_position' => config('bladewind.statistic.currency_position', 'left'),
    'currencyPosition' => config('bladewind.statistic.currency_position', 'left'),
    'label' => '',
    'icon' => '',
    'currency' => config('bladewind.statistic.currency', ''),
    'show_spinner' => false,
    'showSpinner' => false,
    'has_shadow' => config('bladewind.statistic.has_shadow', true),
    'hasShadow' => config('bladewind.statistic.has_shadow', true),
    'hasBorder' => config('bladewind.statistic.has_border', true),
    'class' => '',
    'number_css' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $show_spinner = filter_var($show_spinner, FILTER_VALIDATE_BOOLEAN);
    $showSpinner = filter_var($showSpinner, FILTER_VALIDATE_BOOLEAN);
    $has_shadow = filter_var($has_shadow, FILTER_VALIDATE_BOOLEAN);
    $hasShadow = filter_var($hasShadow, FILTER_VALIDATE_BOOLEAN);
    $has_border = filter_var($hasBorder, FILTER_VALIDATE_BOOLEAN);
    if ($labelPosition !== $label_position) $label_position = $labelPosition;
    if ($iconPosition !== $icon_position) $icon_position = $iconPosition;
    if ($currencyPosition !== $currency_position) $currency_position = $currencyPosition;
    if ($showSpinner) $show_spinner = $showSpinner;
    if (!$hasShadow) $has_shadow = $hasShadow;
    $shadow_css = ($has_shadow) ? 'drop-shadow-sm shadow-sm shadow-slate-200 dark:shadow-dark-800/70' : '';
    $border_css = ($has_border) ? 'border border-gray-100/80 dark:border-dark-600/60' : '';
?>

<div <?php echo e($attributes(['class' => "bw-statistic bg-white dark:bg-dark-800/30 focus:outline-none p-6 rounded-md relative $shadow_css $border_css $class"])); ?>>
    <div class="flex space-x-4">
        <?php if($icon !== '' && $icon_position=='left'): ?>
            <div class="grow-0 icon"><?php echo $icon; ?></div>
        <?php endif; ?>
        <div class="grow number">
            <?php if($label_position=='top'): ?>
                <div class="uppercase tracking-wider text-xs text-gray-500/90 mb-1 label"><?php echo $label; ?></div>
            <?php endif; ?>
            <div class="text-3xl text-gray-500/90 font-light">
                <?php if($show_spinner): ?>
                    <?php if (isset($component)) { $__componentOriginal0285c67f0472b8447eb8291a5277f908 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0285c67f0472b8447eb8291a5277f908 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.spinner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $attributes = $__attributesOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__attributesOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $component = $__componentOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__componentOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if($currency!=='' && $currency_position == 'left'): ?>
                    <span class="text-gray-300 dark:text-slate-600 mr-1 text-2xl"><?php echo $currency; ?></span>
                <?php endif; ?><span
                        class="figure tracking-wider dark:text-slate-400 font-semibold <?php echo e($number_css); ?>"><?php echo e($number); ?></span><?php if($currency!=='' && $currency_position == 'right'): ?>
                    <span class="text-gray-300 dark:text-slate-600 ml-1 text-2xl"><?php echo $currency; ?></span>
                <?php endif; ?>
            </div>
            <?php if($label_position=='bottom'): ?>
                <div class="uppercase tracking-wider text-xs text-gray-500/90 mt-1 label"><?php echo $label; ?></div>
            <?php endif; ?>
            <?php echo e($slot); ?>

        </div>
        <?php if($icon !== '' && $icon_position=='right'): ?>
            <div class="grow-0 icon"><?php echo $icon; ?></div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\statistic.blade.php ENDPATH**/ ?>