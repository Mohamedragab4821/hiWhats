<?php use Illuminate\Support\Str; ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => '',
    'percentage' => 0,
    'color' => config('bladewind.horizontal_line_graph.color', 'primary'),
    'shade' => config('bladewind.horizontal_line_graph.shade', 'faint'),
    'percentage_label_opacity' => config('bladewind.horizontal_line_graph.percentage_label_opacity', 50),
    'percentageLabelOpacity' => config('bladewind.horizontal_line_graph.percentage_label_opacity', 50),
    'class' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => '',
    'percentage' => 0,
    'color' => config('bladewind.horizontal_line_graph.color', 'primary'),
    'shade' => config('bladewind.horizontal_line_graph.shade', 'faint'),
    'percentage_label_opacity' => config('bladewind.horizontal_line_graph.percentage_label_opacity', 50),
    'percentageLabelOpacity' => config('bladewind.horizontal_line_graph.percentage_label_opacity', 50),
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    if( $percentageLabelOpacity !== $percentage_label_opacity) $percentage_label_opacity = $percentageLabelOpacity;
?>
<span class="opacity-0 opacity-5 opacity-10 opacity-20 opacity-25 opacity-30 opacity-40 opacity-50 opacity-60 opacity-70 opacity-75 opacity-80 opacity-90 opacity-95 opacity-100"></span>
<?php if (isset($component)) { $__componentOriginal3e816710529890da4c2a689d494dc5dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e816710529890da4c2a689d494dc5dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.progress-bar','data' => ['percentage' => ''.e($percentage).'','shade' => ''.e($shade).'','color' => ''.e($color).'','percentagePrefix' => ''.e($label).'','showPercentageLabel' => 'true','showPercentageLabelInline' => 'false','percentageLabelPosition' => 'top left','percentageLabelOpacity' => ''.e($percentage_label_opacity).'','class' => ''.e($class).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::progress-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['percentage' => ''.e($percentage).'','shade' => ''.e($shade).'','color' => ''.e($color).'','percentage_prefix' => ''.e($label).'','show_percentage_label' => 'true','show_percentage_label_inline' => 'false','percentage_label_position' => 'top left','percentage_label_opacity' => ''.e($percentage_label_opacity).'','class' => ''.e($class).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e816710529890da4c2a689d494dc5dd)): ?>
<?php $attributes = $__attributesOriginal3e816710529890da4c2a689d494dc5dd; ?>
<?php unset($__attributesOriginal3e816710529890da4c2a689d494dc5dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e816710529890da4c2a689d494dc5dd)): ?>
<?php $component = $__componentOriginal3e816710529890da4c2a689d494dc5dd; ?>
<?php unset($__componentOriginal3e816710529890da4c2a689d494dc5dd); ?>
<?php endif; ?><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\horizontal-line-graph.blade.php ENDPATH**/ ?>