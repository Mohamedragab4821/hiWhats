<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([ 
    // to create a radio button group, specify the same name
    // for all the radio buttons in the group
    'name' => 'radio',
    'value' => '',
    'label' => '',
    'label_css' => 'mr-6',
    'labelCss' => 'mr-6',
    'color' => 'blue',
    'checked' => false,
    'add_clearing' => config('bladewind.radio_button.add_clearing', true),
    'class' => '',
    'disabled' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([ 
    // to create a radio button group, specify the same name
    // for all the radio buttons in the group
    'name' => 'radio',
    'value' => '',
    'label' => '',
    'label_css' => 'mr-6',
    'labelCss' => 'mr-6',
    'color' => 'blue',
    'checked' => false,
    'add_clearing' => config('bladewind.radio_button.add_clearing', true),
    'class' => '',
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $checked = filter_var($checked, FILTER_VALIDATE_BOOLEAN);
    $disabled = filter_var($disabled, FILTER_VALIDATE_BOOLEAN);
    $label_css = (!empty($labelCss)) ? $labelCss : $label_css;
?>
<?php if (isset($component)) { $__componentOriginal701009bc86ef91af6041f0e4d6588e8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.checkbox','data' => ['name' => ''.e($name).'','label' => ''.e($label).'','value' => ''.e($value).'','color' => ''.e($color).'','class' => 'rounded-full '.e($class).'','labelCss' => ''.e($label_css).'','disabled' => ''.e($disabled).'','checked' => ''.e($checked).'','type' => 'radio']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'','label' => ''.e($label).'','value' => ''.e($value).'','color' => ''.e($color).'','class' => 'rounded-full '.e($class).'','label_css' => ''.e($label_css).'','disabled' => ''.e($disabled).'','checked' => ''.e($checked).'','type' => 'radio']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $attributes = $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $component = $__componentOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\radio-button.blade.php ENDPATH**/ ?>