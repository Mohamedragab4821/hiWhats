<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([ 
    'name' => 'processing',

    // the process indicator is rendered within the page and so by default
    // its hidden until a process needs to be started
    // you can set this to false to unhide the process indicator on page load
    'hide' => true,
    
    // message to display when the process is running
    'message' => '',
    'class' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([ 
    'name' => 'processing',

    // the process indicator is rendered within the page and so by default
    // its hidden until a process needs to be started
    // you can set this to false to unhide the process indicator on page load
    'hide' => true,
    
    // message to display when the process is running
    'message' => '',
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $name = preg_replace('/[\s]/', '-', $name);
    $hide = filter_var($hide, FILTER_VALIDATE_BOOLEAN);
?>
<div class="<?php echo e($name); ?> text-center text-sm <?php if($hide): ?> hidden <?php endif; ?> mt-6 <?php echo e($class); ?>">
    <?php if (isset($component)) { $__componentOriginal0285c67f0472b8447eb8291a5277f908 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0285c67f0472b8447eb8291a5277f908 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.spinner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bladewind::spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $attributes = $__attributesOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__attributesOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $component = $__componentOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__componentOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
    <div class="my-3 text-gray-400 process-message"><?php echo e($message); ?></div>
</div><?php /**PATH C:\Users\Mahmoud Ahmed\OneDrive\Desktop\marketing_laravel\hiWhats\vendor\mkocansey\bladewind\resources\views\components\processing.blade.php ENDPATH**/ ?>